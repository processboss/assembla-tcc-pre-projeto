package br.com.globosat.gcredirect.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Exibe a página de erro para recursos não autorizados.
 * 
 * @author Marcelo Rezende Módolo
 * 
 */
@Controller
@RequestMapping(value = "/accessDenied")
public class AccessDeniedController {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(AccessDeniedController.class);

	@RequestMapping(method = RequestMethod.GET)
	public String getView() {
		LOGGER.debug("view: security/AccessDenied");
		return "security/AccessDenied";
	}

}
