package br.com.globosat.gcredirect.controller;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;
import br.com.globosat.gcredirect.service.SitioService;
import br.com.globosat.gcredirect.service.UsuarioService;

@Controller
@SessionAttributes({ "userDetails" })
public class EditorController {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(EditorController.class);

	@Autowired
	UsuarioService usuarioService;

	@Autowired
	SitioService sitioService;

	@RequestMapping(value = "/editor", method = RequestMethod.GET)
	public String getEditorLista(@RequestParam("siglaSitio") String siglaSitio,
			Model model) {
		List<Usuario> editores = Collections.emptyList();
		Sitio s = sitioService.findOneBySitioSigla(siglaSitio);
		LOGGER.debug("getEditorLista => Sitio: " + s);
		editores = usuarioService.findAllBySitio(s);
		LOGGER.debug("getEditorLista => Total de editores obtido: "
				+ editores.size());
		model.addAttribute("editores", editores);
		model.addAttribute("nomeSitio", s.getNome());
		return "/administrador/listaEditores";
	}

}
