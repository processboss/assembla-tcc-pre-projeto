package br.com.globosat.gcredirect.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Exibe a página de login no sistema.
 * 
 * @author Marcelo Rezende Módolo
 *
 */
@Controller
public class LoginLogoutController {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(LoginLogoutController.class);
	
	@RequestMapping(method=RequestMethod.GET,value="/login")
	public String getLoginView() {
		LOGGER.debug("view: security/Login");
		return "security/Login";
	}
	
	@RequestMapping(method=RequestMethod.GET,value="/logout")
	public String getLogoutView() {
		LOGGER.debug("view: security/Logout");
		return "security/Logout";
	}
	
}
