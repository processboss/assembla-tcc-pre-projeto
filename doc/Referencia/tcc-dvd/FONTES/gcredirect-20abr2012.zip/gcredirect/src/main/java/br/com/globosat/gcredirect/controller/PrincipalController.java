package br.com.globosat.gcredirect.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import br.com.globosat.gcredirect.security.GCRedirectUserDetails;

@Controller
@SessionAttributes({"userDetails"})
public class PrincipalController {

	private static final String ROLE_ADMIN = "ROLE_ADMIN";


	private static final Logger LOGGER = LoggerFactory
			.getLogger(PrincipalController.class);

	public PrincipalController() {
	}

	@RequestMapping(value = "/principal", method = RequestMethod.GET)
	public String getPrincipal(ModelMap modelMap) {

		final GCRedirectUserDetails userDetails = (GCRedirectUserDetails) SecurityContextHolder
				.getContext().getAuthentication().getPrincipal();
		modelMap.addAttribute("userDetails", userDetails);
		
		final String destino = isAdministrador(userDetails) ? "/administrador/index"
				: "/redirecionamento/index";

		LOGGER.debug("Destino: " + destino);
		return destino;
	}

	//sitio/editores
	@RequestMapping(value = "/sitio/editores", method = RequestMethod.GET)
	public String getSitioEditores(ModelMap modelMap) {
		
		return "/administrador/sitioEditores";
	}
	
	private boolean isAdministrador(GCRedirectUserDetails userDetails) {

		for (GrantedAuthority ga : userDetails.getAuthorities()) {
			if (ROLE_ADMIN.equalsIgnoreCase(ga.getAuthority())) {
				return true;
			}
		}
		return false;
	}

}
