package br.com.globosat.gcredirect.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Um redirecionamento permite que uma URL antiga aponte para uma URL nova.
 * 
 * @author "Marcelo Rezende Módolo"
 * 
 */
@Entity
@Table(name = "historico_redirecionamento")
public class HistoricoRedirecionamento implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3661114590066592135L;

	public static enum Acao {
		CRIAR("CRIAR"), EXCLUIR("EXCLUIR");

		private final String descricao;

		private Acao(String descricao) {
			this.descricao = descricao;
		}

		@Override
		public String toString() {
			return descricao;
		}

		public static Acao fromString(String descricao) {
			Acao a = null;
			for (Acao item : Acao.values()) {
				if (item.getDescricao().equalsIgnoreCase(descricao)) {
					a = item;
					break;
				}
			}
			return a;
		}

		public String getDescricao() {
			return descricao;
		}
	};

	@Id
	@SequenceGenerator( name = "HISTORICO_REDIRECIONAMENTO_SEQ", sequenceName = "historico_redirecionamento_id_seq", allocationSize = 1 )  
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="HISTORICO_REDIRECIONAMENTO_SEQ")
	private Long id;

	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_usuario")
	private Usuario usuario;

	@ManyToOne(cascade = { CascadeType.ALL }, fetch = FetchType.EAGER)
	@JoinColumn(name = "id_sitio")
	private Sitio sitio;

	@Column(name = "id_redirecionamento", nullable = false)
	private Long idRedirecionamento;
	
	@Column(name = "acao", nullable = false)
	private String acao;

	@Column(name = "status", nullable = false)
	private int status;

	@Column(name = "url_antiga", nullable = false, unique = true)
	private String urlAntiga;

	@Column(name = "url_nova", nullable = false)
	private String urlNova;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "data", nullable = false)
	private Date data;

	public HistoricoRedirecionamento() {
	}

	/**
	 * Cria um histórico de redirecionamento a partir de um redirecionamento,<br>
	 * com a data atual.
	 * @param redirecionamento
	 * @param usuario
	 * @param acao
	 */
	public HistoricoRedirecionamento(Redirecionamento redirecionamento,
			Usuario usuario, Acao acao) {
		this(redirecionamento, usuario, acao, new Date());
	}
	
	/**
	 * Cria um histórico de redirecionamento a partir de um redirecionamento.
	 * 
	 * @param redirecionamento
	 * @param autor
	 * @param acao
	 * @param date
	 */
	public HistoricoRedirecionamento(Redirecionamento redirecionamento, 
			Usuario usuario, Acao acao, Date data) {
		this(null, usuario, redirecionamento.getSitio(), acao, redirecionamento
				.getStatus(), redirecionamento.getUrlAntiga(), redirecionamento
				.getUrlNova(), data);
		this.idRedirecionamento = redirecionamento.getId();
	}

	/**
	 * 
	 * @param id
	 * @param usuario
	 * @param sitio
	 * @param acao
	 * @param status
	 * @param urlAntiga
	 * @param urlNova
	 * @param data
	 */
	private HistoricoRedirecionamento(Long id, Usuario usuario, Sitio sitio,
			Acao acao, StatusRedirecionamento status, String urlAntiga,
			String urlNova, Date data) {
		super();

		validarUsuario(usuario);
		validarSitio(sitio);
		validarUrlAntiga(urlAntiga);
		validarUrlNova(urlNova);
		validarData(data);

		this.id = id;
		this.usuario = usuario;
		this.sitio = sitio;
		this.acao = acao.getDescricao();
		this.status = status.getStatusCode();
		this.urlAntiga = urlAntiga;
		this.urlNova = urlNova;
		this.data = data;
	}

	private void validarUrlAntiga(String urlAntiga) {
		if ((urlAntiga == null) || "".equals(urlAntiga)) {
			throw new IllegalArgumentException(
					"URL antiga não pode ser vazio ou nulo");
		}

	}

	private void validarUrlNova(String urlNova) {
		if ((urlNova == null) || "".equals(urlNova)) {
			throw new IllegalArgumentException(
					"URL nova não pode ser vazio ou nulo");
		}

	}

	private void validarSitio(Sitio sitio) {
		if ((sitio == null)) {
			throw new IllegalArgumentException("Sítio não pode ser nulo");
		}

	}

	private void validarUsuario(Usuario usuario) {
		if ((usuario == null)) {
			throw new IllegalArgumentException("Usuário não pode ser nulo");
		}

	}

	private void validarData(Date data) {
		if ((data == null)) {
			throw new IllegalArgumentException("Data não pode ser nulo");
		}

	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the usuario
	 */
	public Usuario getUsuario() {
		return usuario;
	}

	/**
	 * @param usuario
	 *            the usuario to set
	 */
	public void setUsuario(Usuario usuario) {
		validarUsuario(usuario);
		this.usuario = usuario;
	}

	/**
	 * @return the sitio
	 */
	public Sitio getSitio() {
		return sitio;
	}

	/**
	 * @param sitio
	 *            the sitio to set
	 */
	public void setSitio(Sitio sitio) {
		validarSitio(sitio);
		this.sitio = sitio;
	}

	/**
	 * 
	 * @return o ID do redirecionamento
	 */
	public Long getIdRedirecionamento() {
		return idRedirecionamento;
	}
	
	/**
	 * @return the acao
	 */
	public Acao getAcao() {
		return Acao.fromString(this.acao);
	}

	/**
	 * @param acao
	 *            the acao to set
	 */
	public void setAcao(Acao acao) {
		this.acao = acao.getDescricao();
	}

	/**
	 * @return the status
	 */
	public StatusRedirecionamento getStatus() {
		return StatusRedirecionamento.fromInt(status);
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(StatusRedirecionamento status) {
		this.status = status.getStatusCode();
	}

	/**
	 * @return the urlAntiga
	 */
	public String getUrlAntiga() {
		return urlAntiga;
	}

	/**
	 * @param urlAntiga
	 *            the urlAntiga to set
	 */
	public void setUrlAntiga(String urlAntiga) {
		validarUrlAntiga(urlAntiga);
		this.urlAntiga = urlAntiga;
	}

	/**
	 * @return the urlNova
	 */
	public String getUrlNova() {
		return urlNova;
	}

	/**
	 * @param urlNova
	 *            the urlNova to set
	 */
	public void setUrlNova(String urlNova) {
		validarUrlNova(urlNova);
		this.urlNova = urlNova;
	}

	/**
	 * @return the data
	 */
	public Date getData() {
		return data;
	}

	/**
	 * @param data
	 *            the data to set
	 */
	public void setData(Date data) {
		this.data = data;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HistoricoRedirecionamento other = (HistoricoRedirecionamento) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "HistoricoRedirecionamento [id=" + id + ", usuario=" + usuario
				+ ", sitio=" + sitio + ", idRedirecionamento="
				+ idRedirecionamento + ", acao=" + acao + ", status=" + status
				+ ", urlAntiga=" + urlAntiga + ", urlNova=" + urlNova
				+ ", data=" + data + "]";
	}

}
