package br.com.globosat.gcredirect.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Um redirecionamento permite que uma URL antiga aponte
 * para uma URL nova.
 * 
 * @author "Marcelo Rezende Módolo"
 *
 */
@Entity
@Table(name="redirecionamento")
public class Redirecionamento implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9113087648459458882L;

	@Id
	@SequenceGenerator( name = "REDIRECIONAMENTO_SEQ", sequenceName = "redirecionamento_id_seq", allocationSize = 1 )  
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="REDIRECIONAMENTO_SEQ")
	private Long id;
	
	@ManyToOne(cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
	@JoinColumn(name="id_sitio")
	private Sitio sitio;
	
	@Column(name="status",nullable=false)
	private int status;
	
	@Column(name="url_antiga",nullable=false,unique=true)
	private String urlAntiga;
	
	@Column(name="url_nova",nullable=false)
	private String urlNova;
	
	public Redirecionamento() {
	}

	/**
	 * @param id
	 * @param sitio
	 * @param status
	 * @param urlAntiga
	 * @param urlNova
	 */
	public Redirecionamento(Long id, Sitio sitio, StatusRedirecionamento status, String urlAntiga,
			String urlNova) {
		super();
		
		validarSitio(sitio);
		validarUrlAntiga(urlAntiga);
		validarUrlNova(urlNova);
		
		this.id = id;
		this.sitio = sitio;
		this.status = status.getStatusCode();
		this.urlAntiga = urlAntiga;
		this.urlNova = urlNova;
	}

	private void validarUrlAntiga(String urlAntiga) {
		if ((urlAntiga == null) || "".equals(urlAntiga)) {
			throw new IllegalArgumentException(
					"URL antiga não pode ser vazio ou nulo");
		}

	}

	private void validarUrlNova(String urlNova) {
		if ((urlNova == null) || "".equals(urlNova)) {
			throw new IllegalArgumentException(
					"URL nova não pode ser vazio ou nulo");
		}

	}

	private void validarSitio(Sitio sitio) {
		if ((sitio == null)) {
			throw new IllegalArgumentException(
					"Sítio não pode ser nulo");
		}

	}
	
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the sitio
	 */
	public Sitio getSitio() {
		return sitio;
	}

	/**
	 * @param sitio the sitio to set
	 */
	public void setSitio(Sitio sitio) {
		validarSitio(sitio);
		this.sitio = sitio;
	}

	/**
	 * @return the status
	 */
	public StatusRedirecionamento getStatus() {
		return StatusRedirecionamento.fromInt(status);
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusRedirecionamento status) {
		this.status = status.getStatusCode();
	}

	/**
	 * @return the urlAntiga
	 */
	public String getUrlAntiga() {
		return urlAntiga;
	}

	/**
	 * @param urlAntiga the urlAntiga to set
	 */
	public void setUrlAntiga(String urlAntiga) {
		validarUrlAntiga(urlAntiga);
		this.urlAntiga = urlAntiga;
	}

	/**
	 * @return the urlNova
	 */
	public String getUrlNova() {
		return urlNova;
	}

	/**
	 * @param urlNova the urlNova to set
	 */
	public void setUrlNova(String urlNova) {
		validarUrlNova(urlNova);
		this.urlNova = urlNova;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((sitio == null) ? 0 : sitio.hashCode());
		result = prime * result
				+ ((urlAntiga == null) ? 0 : urlAntiga.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Redirecionamento other = (Redirecionamento) obj;
		if (sitio == null) {
			if (other.sitio != null)
				return false;
		} else if (!sitio.equals(other.sitio))
			return false;
		if (urlAntiga == null) {
			if (other.urlAntiga != null)
				return false;
		} else if (!urlAntiga.equals(other.urlAntiga))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Redirecionamento [id=" + id + ", sitio=" + sitio + ", status="
				+ status + ", urlAntiga=" + urlAntiga + ", urlNova=" + urlNova
				+ "]";
	}
	
	
}
