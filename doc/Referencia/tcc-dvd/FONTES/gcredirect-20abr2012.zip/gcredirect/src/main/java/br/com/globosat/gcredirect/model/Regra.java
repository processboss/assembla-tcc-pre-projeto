package br.com.globosat.gcredirect.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Define o papel na autenticação.
 * 
 * @author "Marcelo Rezende Módolo"
 *
 */
@Entity
@Table(name="regra")
public class Regra implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -458763953380568933L;

	@Id
	@SequenceGenerator( name = "REGRA_SEQ", sequenceName = "regra_id_seq", allocationSize = 1 )  
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="REGRA_SEQ")
	private Long id;
	
	@Column(name="nome",nullable=false,unique=true)
	private String nome;
	
	public Regra() {
	}

	/**
	 * 
	 * @param id
	 * @param nome
	 */
	public Regra(Long id, String nome) {
		super();
		validarNome(nome);
		this.id = id;
		this.nome = nome;
	}

	private void validarNome(String nome) {
		if ((nome == null) || "".equals(nome)) {
			throw new IllegalArgumentException(
					"Nome não pode ser vazio ou nulo");
		}

	}
	
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		validarNome(nome);
		this.nome = nome;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Regra other = (Regra) obj;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Regra [id=" + id + ", nome=" + nome + "]";
	}
	
	
}
