package br.com.globosat.gcredirect.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Um sítio Web
 * 
 * @author "Marcelo Rezende Módolo"
 *
 */
@Entity
@Table(name="sitio")
public class Sitio implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7376224670927748077L;

	@Id
	@SequenceGenerator( name = "SITIO_SEQ", sequenceName = "sitio_id_seq", allocationSize = 1 )  
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="SITIO_SEQ")
	private Long id;
	
	@Column(name="nome",nullable=false,unique=true)
	private String nome;
	
	@Column(name="sigla",nullable=false,unique=true)
	private String sigla;
	
	@Column(name="url_sitio",nullable=false,unique=true)
	private String urlSitio;
	
	@Column(name="caminho_arquivo_redirecionamento",nullable=false)
	private String caminhoArquivoRedirecionamento;
	
	@Column(name="arquivo_redirecionamento",nullable=false)
	private String arquivoRedirecionamento;
	
	public Sitio() {
	}

	/**
	 * 
	 * @param id
	 * @param nome
	 * @param sigla
	 * @param urlSitio
	 * @param caminhoArquivoRedirecionamento
	 * @param arquivoRedirecionamento
	 */
	public Sitio(Long id, String nome, String sigla, String urlSitio,
			String caminhoArquivoRedirecionamento,
			String arquivoRedirecionamento) {
		super();
		this.id = id;
		this.nome = nome;
		this.sigla = sigla;
		this.urlSitio = urlSitio;
		this.caminhoArquivoRedirecionamento = caminhoArquivoRedirecionamento;
		this.arquivoRedirecionamento = arquivoRedirecionamento;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * @return the sigla
	 */
	public String getSigla() {
		return sigla;
	}

	/**
	 * @param sigla the sigla to set
	 */
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

	/**
	 * @return the urlSitio
	 */
	public String getUrlSitio() {
		return urlSitio;
	}

	/**
	 * @param urlSitio the urlSitio to set
	 */
	public void setUrlSitio(String urlSitio) {
		this.urlSitio = urlSitio;
	}

	/**
	 * @return the caminhoArquivoRedirecionamento
	 */
	public String getCaminhoArquivoRedirecionamento() {
		return caminhoArquivoRedirecionamento;
	}

	/**
	 * @param caminhoArquivoRedirecionamento the caminhoArquivoRedirecionamento to set
	 */
	public void setCaminhoArquivoRedirecionamento(
			String caminhoArquivoRedirecionamento) {
		this.caminhoArquivoRedirecionamento = caminhoArquivoRedirecionamento;
	}

	/**
	 * @return the arquivoRedirecionamento
	 */
	public String getArquivoRedirecionamento() {
		return arquivoRedirecionamento;
	}

	/**
	 * @param arquivoRedirecionamento the arquivoRedirecionamento to set
	 */
	public void setArquivoRedirecionamento(String arquivoRedirecionamento) {
		this.arquivoRedirecionamento = arquivoRedirecionamento;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((sigla == null) ? 0 : sigla.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sitio other = (Sitio) obj;
		if (sigla == null) {
			if (other.sigla != null)
				return false;
		} else if (!sigla.equals(other.sigla))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Sitio [id=" + id + ", nome=" + nome + ", sigla=" + sigla
				+ ", urlSitio=" + urlSitio
				+ ", caminhoArquivoRedirecionamento="
				+ caminhoArquivoRedirecionamento + ", arquivoRedirecionamento="
				+ arquivoRedirecionamento + "]";
	}
	
	
}
