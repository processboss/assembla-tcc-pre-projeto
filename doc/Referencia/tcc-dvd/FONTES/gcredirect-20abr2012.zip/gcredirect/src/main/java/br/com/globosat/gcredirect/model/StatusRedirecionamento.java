package br.com.globosat.gcredirect.model;

import java.io.Serializable;

/**
 * Os diversos tipos de Redirecionamentos.
 * 
 * @author "Marcelo Rezende Módolo"
 *
 */
public enum StatusRedirecionamento implements Serializable {

	PERMANENT(301);
	
	private final int statusCode;
	
	private StatusRedirecionamento(int statusCode) {
		this.statusCode = statusCode;
	}
		
	public int getStatusCode() {
		return statusCode;
	}

	/**
	 * JPA só permite duas maneiras de lidar com enums, 
	 * pelo seu nome ou pelo seu valor ordinal.
	 * Assim é necessário anotar os métodos get e set e 
	 * retornar o valor inteiro correspondente.
	 *  
	 * @param statusCode
	 * @return
	 */
	public static StatusRedirecionamento fromInt(int statusCode) {
		StatusRedirecionamento statusRedirecionamento = null;
		for (StatusRedirecionamento item : StatusRedirecionamento.values()) {
			if (item.getStatusCode() == statusCode ) {
				statusRedirecionamento = item;
				break;
			}
		}
		return statusRedirecionamento;
	}
	@Override
	public String toString() {
		String statusCodeStr = ""; 
		switch(statusCode) {
			case 301:
				statusCodeStr = "permanent";
				break;
			case 302:
				statusCodeStr = "temp";
				break;
			case 303:
				statusCodeStr = "seeother";
				break;
			case 410:
				statusCodeStr = "gone";
				break;
		}
		return statusCodeStr;
	}
}
