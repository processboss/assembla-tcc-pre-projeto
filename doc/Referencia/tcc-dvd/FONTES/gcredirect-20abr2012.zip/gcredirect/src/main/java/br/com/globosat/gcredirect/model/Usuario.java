package br.com.globosat.gcredirect.model;

import java.io.Serializable;
import java.util.Collections;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Usuário do sistema.
 * 
 * @author "Marcelo Rezende Módolo"
 * 
 */
@Entity
@Table(name = "usuario")
public class Usuario implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7489962213689451815L;

	@Id
	@SequenceGenerator( name = "USUARIO_SEQ", sequenceName = "usuario_id_seq", allocationSize = 1 )  
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="USUARIO_SEQ")
	private Long id;

	@Column(name = "nome", nullable = false)
	private String nome;

	@Column(name = "email", nullable = false)
	private String email;

	@Column(name = "senha", nullable = false)
	private String senha;

	@Column(name = "usuario", nullable = false, unique = true)
	private String usuario;

	@Column(name = "ativo", nullable = false)
	private boolean ativo;

	@Column(name = "telefone", nullable = false)
	private String telefone;

	@ManyToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	@JoinTable(
			name="regra_usuario",
			joinColumns = @JoinColumn(name="id_usuario"),
			inverseJoinColumns = @JoinColumn(name = "id_regra")
	)
	private Set<Regra> regras = Collections.emptySet();

	@ManyToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinTable(
			name="sitio_usuario",
			joinColumns = @JoinColumn(name="id_usuario"),
			inverseJoinColumns = @JoinColumn(name = "id_sitio")
	)	
	private Set<Sitio> sitios = Collections.emptySet();

	public Usuario() {
	}

	/**
	 * @param id
	 * @param nome
	 * @param email
	 * @param senha
	 * @param usuario
	 * @param ativo
	 * @param telefone
	 * @param regras
	 * @param sitios
	 */
	public Usuario(Long id, String nome, String email, String senha,
			String usuario, boolean ativo, String telefone, Set<Regra> regras,
			Set<Sitio> sitios) {
		super();
		
		validarNome(nome);
		validarEmail(email);
		validarSenha(senha);
		validarUsuario(usuario);
		validarTelefone(telefone);
		validarRegras(regras);
		validarSitios(sitios);
		
		this.id = id;
		this.nome = nome;
		this.email = email;
		this.senha = senha;
		this.usuario = usuario;
		this.ativo = ativo;
		this.telefone = telefone;
		this.regras = regras;
		this.sitios = sitios;
	}

	private void validarNome(String nome) {
		if ((nome == null) || "".equals(nome)) {
			throw new IllegalArgumentException(
					"Nome não pode ser vazio ou nulo");
		}

	}

	private void validarEmail(String email) {
		if ((email == null) || "".equals(email)) {
			throw new IllegalArgumentException(
					"E-mail não pode ser vazio ou nulo");
		}

	}

	private void validarSenha(String senha) {
		if ((senha == null) || "".equals(senha)) {
			throw new IllegalArgumentException(
					"Senha não pode ser vazio ou nulo");
		}
	}

	private void validarUsuario(String usuario) {
		if ((usuario == null) || "".equals(usuario)) {
			throw new IllegalArgumentException(
					"Usuário não pode ser vazio ou nulo");
		}

	}

	private void validarTelefone(String telefone) {
		if ((telefone == null) || "".equals(telefone)) {
			throw new IllegalArgumentException(
					"Telefone não pode ser vazio ou nulo");
		}

	}

	private void validarRegras(Set<Regra> regras) {
		if ((regras == null)) {
			throw new IllegalArgumentException(
					"Regras não pode ser nulo");
		}
		for (Regra r : regras) {
			if ( r == null ) {
				throw new IllegalArgumentException(
						"Regras não pode conter um elemento nulo");				
			}
		}
	}

	private void validarSitios(Set<Sitio> sitios) {
		if ((sitios == null) ) {
			throw new IllegalArgumentException(
					"Sítios não pode ser nulo");
		}
		for (Sitio s : sitios) {
			if ( s == null ) {
				throw new IllegalArgumentException(
						"Sítios não pode conter um elemento nulo");				
			}
		}
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @param nome
	 *            the nome to set
	 */
	public void setNome(String nome) {
		validarNome(nome);
		this.nome = nome;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		validarEmail(email);
		this.email = email;
	}

	/**
	 * @return the senha
	 */
	public String getSenha() {
		return senha;
	}

	/**
	 * @param senha
	 *            the senha to set
	 */
	public void setSenha(String senha) {
		validarSenha(senha);
		this.senha = senha;
	}

	/**
	 * @return the usuario
	 */
	public String getUsuario() {
		return usuario;
	}

	/**
	 * @param usuario
	 *            the usuario to set
	 */
	public void setUsuario(String usuario) {
		validarUsuario(usuario);
		this.usuario = usuario;
	}

	/**
	 * @return the ativo
	 */
	public boolean isAtivo() {
		return ativo;
	}

	/**
	 * @param ativo
	 *            the ativo to set
	 */
	public void setAtivo(boolean ativo) {
		this.ativo = ativo;
	}

	/**
	 * @return the telefone
	 */
	public String getTelefone() {
		return telefone;
	}

	/**
	 * @param telefone
	 *            the telefone to set
	 */
	public void setTelefone(String telefone) {
		validarTelefone(telefone);
		this.telefone = telefone;
	}

	/**
	 * @return the regras
	 */
	public Set<Regra> getRegras() {
		return Collections.unmodifiableSet(regras);
	}

	/**
	 * @param regras
	 *            the regras to set
	 */
	public void setRegras(Set<Regra> regras) {
		validarRegras(regras);
		this.regras.addAll(regras);
	}

	/**
	 * @return the sitios
	 */
	public Set<Sitio> getSitios() {
		return Collections.unmodifiableSet(sitios);
	}

	/**
	 * @param sitios
	 *            the sitios to set
	 */
	public void setSitios(Set<Sitio> sitios) {
		validarSitios(sitios);
		this.sitios = sitios;
	}

	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Usuario [id=" + id + ", nome=" + nome + ", email=" + email
				+ ", senha=" + senha + ", usuario=" + usuario + ", ativo="
				+ ativo + ", telefone=" + telefone + ", regras=" + regras
				+ ", sitios=" + sitios + "]";
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((usuario == null) ? 0 : usuario.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		if (usuario == null) {
			if (other.usuario != null)
				return false;
		} else if (!usuario.equals(other.usuario))
			return false;
		return true;
	}


}
