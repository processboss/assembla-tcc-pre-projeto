package br.com.globosat.gcredirect.repository;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import br.com.globosat.gcredirect.model.HistoricoRedirecionamento;
import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;

/*
 * We use @Transactional to make sure the save(…) operation is running in 
 * a transaction and to allow setting the readOnly-flag (at the class level) 
 * for findAll(...), findOne(...). 
 * This causes some performance optimizations inside the persistence provider 
 * as well as on the database level.
 */

/*
 * @Service serves as a specialization of @Component, allowing for 
 * implementation classes to be autodetected through classpath scanning. 
 * What this means is that you could annotate your service-layer 
 * classes with @Component, but by annotating them with @Service instead, 
 * your classes are more properly suited for processing by tools or 
 * associating with aspects, since @Service makes an ideal target for pointcuts.
 */

/**
 * 
 * @author "Marcelo Rezende Módolo"
 * 
 */
@Repository
@Transactional(readOnly = true)
public interface HistoricoRedirecionamentoRepository {
	
	/**
	 * Retorna todo o histórico de redirecionamentos associados a um usuário.
	 * 
	 * @param usuario
	 * @return
	 */
	public abstract List<HistoricoRedirecionamento> findAllByUsuario(Usuario usuario);

	/**
	 * Retorna todo o histórico de redirecionamentos associados a um usuário.
	 * 
	 * @param id
	 * @return
	 */
	public abstract List<HistoricoRedirecionamento> findAllByUsuario(Long id);

	/**
	 * Retorna todo o histórico de redirecionamentos associados a um sítio,<br>
	 * ordenado pela data da operação
	 * 
	 * @param sitio
	 * @return
	 */
	public abstract List<HistoricoRedirecionamento> findAllBySitio(Sitio sitio);

	/**
	 * Retorna todo o histórico de redirecionamentos associados a um sítio,<br>
	 * ordenado pela data da operação
	 * @param id
	 * @return
	 */
	public abstract List<HistoricoRedirecionamento> findAllBySitio(Long id);

	/**
	 * Retorna todo o histórico de redirecionamentos associados a um sítio<br>
	 * e sua URL nova (destino) ordenados pela data da operação.
	 * @param sitio
	 * @param urlNova
	 * @return
	 */
	public abstract List<HistoricoRedirecionamento> findAllBySitioUrlNova(Sitio sitio, String urlNova);

	/**
	 * Retorna todo o histórico de redirecionamentos associados a um sítio<br>
	 * e sua URL anterior (origem) ordenados pela data da operação.
	 * @param sitio
	 * @param urlAntiga
	 * @return
	 */
	public abstract List<HistoricoRedirecionamento> findAllBySitioUrlAntiga(Sitio sitio, String urlAntiga);

	/**
	 * Retorna o histório para o ID de um redirecionamento.
	 * @param id
	 * @return
	 */
	public abstract List<HistoricoRedirecionamento>  findByRedirecionamentoId(Long id);

	/**
	 * Salva ou atualiza o histórico.
	 * @param hr
	 * @return
	 */
	@Transactional
	public abstract HistoricoRedirecionamento save(HistoricoRedirecionamento hr);
	

}
