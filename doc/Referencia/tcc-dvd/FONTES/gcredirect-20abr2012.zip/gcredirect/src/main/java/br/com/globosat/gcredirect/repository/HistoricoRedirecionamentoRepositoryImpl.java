/**
 * 
 */
package br.com.globosat.gcredirect.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import br.com.globosat.gcredirect.model.HistoricoRedirecionamento;
import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;

/**
 * @author "Marcelo Rezende Módolo"
 * 
 */
@Repository
@Transactional(readOnly = true)
public class HistoricoRedirecionamentoRepositoryImpl implements
		HistoricoRedirecionamentoRepository {

	@PersistenceContext
	private EntityManager em;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.globosat.gcredirect.repository.HistoricoRedirecionamentoRepository
	 * #findAllByUsuario(br.com.globosat.gcredirect.model.Usuario)
	 */
	@Override
	public List<HistoricoRedirecionamento> findAllByUsuario(Usuario usuario) {
		return findAllByUsuario(usuario.getId());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.globosat.gcredirect.repository.HistoricoRedirecionamentoRepository
	 * #findAllByUsuario(java.lang.Long)
	 */
	@Override
	public List<HistoricoRedirecionamento> findAllByUsuario(Long id) {
		Assert.notNull(id, "The given id must not be null!");
		TypedQuery<HistoricoRedirecionamento> q = em
				.createQuery(
						"select h from HistoricoRedirecionamento as h where h.usuario.id = :id order by h.data",
						HistoricoRedirecionamento.class);
		q.setParameter("id", id);
		return q.getResultList();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.globosat.gcredirect.repository.HistoricoRedirecionamentoRepository
	 * #findAllBySitio(br.com.globosat.gcredirect.model.Sitio)
	 */
	@Override
	public List<HistoricoRedirecionamento> findAllBySitio(Sitio sitio) {
		return findAllBySitio(sitio.getId());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.globosat.gcredirect.repository.HistoricoRedirecionamentoRepository
	 * #findAllBySitio(java.lang.Long)
	 */
	@Override
	public List<HistoricoRedirecionamento> findAllBySitio(Long id) {
		Assert.notNull(id, "The given id must not be null!");
		TypedQuery<HistoricoRedirecionamento> q = em
				.createQuery(
						"select h from HistoricoRedirecionamento as h where h.sitio.id = :id order by h.data",
						HistoricoRedirecionamento.class);
		q.setParameter("id", id);
		return q.getResultList();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.globosat.gcredirect.repository.HistoricoRedirecionamentoRepository
	 * #findAllBySitioUrlNova(br.com.globosat.gcredirect.model.Sitio,
	 * java.lang.String)
	 */
	@Override
	public List<HistoricoRedirecionamento> findAllBySitioUrlNova(Sitio sitio,
			String urlNova) {
		TypedQuery<HistoricoRedirecionamento> q = em
				.createQuery(
						"select h from HistoricoRedirecionamento as h where h.sitio = :sitio and h.urlNova like :urlNova order by h.data",
						HistoricoRedirecionamento.class);
		q.setParameter("sitio", sitio);
		q.setParameter("urlNova", urlNova);
		return q.getResultList();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.globosat.gcredirect.repository.HistoricoRedirecionamentoRepository
	 * #findAllBySitioUrlAntiga(br.com.globosat.gcredirect.model.Sitio,
	 * java.lang.String)
	 */
	@Override
	public List<HistoricoRedirecionamento> findAllBySitioUrlAntiga(Sitio sitio,
			String urlAntiga) {
		TypedQuery<HistoricoRedirecionamento> q = em
				.createQuery(
						"select h from HistoricoRedirecionamento h where h.sitio = :sitio and h.urlAntiga like :urlAntiga order by h.data",
						HistoricoRedirecionamento.class);
		q.setParameter("sitio", sitio);
		q.setParameter("urlAntiga", urlAntiga);
		return q.getResultList();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.globosat.gcredirect.repository.HistoricoRedirecionamentoRepository
	 * #findByRedirecionamentoId(java.lang.Long)
	 */
	@Override
	public List<HistoricoRedirecionamento> findByRedirecionamentoId(Long id) {
		Assert.notNull(id, "The given id must not be null!");
		TypedQuery<HistoricoRedirecionamento> q = em
				.createQuery(
						"select hr from HistoricoRedirecionamento hr where hr.id = :id",
						HistoricoRedirecionamento.class);
		q.setParameter("id", id);
		return q.getResultList();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.globosat.gcredirect.repository.HistoricoRedirecionamentoRepository
	 * #save(br.com.globosat.gcredirect.model.HistoricoRedirecionamento)
	 */
	@Override
	@Transactional
	public HistoricoRedirecionamento save(HistoricoRedirecionamento hr) {
		if (hr.getId() == null) {
			em.persist(hr);
			return hr;
		} else {
			return em.merge(hr);
		}
	}

}
