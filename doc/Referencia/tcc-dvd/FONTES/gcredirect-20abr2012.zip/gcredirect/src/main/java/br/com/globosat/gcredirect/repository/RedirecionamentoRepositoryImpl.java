package br.com.globosat.gcredirect.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import br.com.globosat.gcredirect.model.Redirecionamento;
import br.com.globosat.gcredirect.model.Sitio;

@Repository
@Transactional(readOnly = true)
public class RedirecionamentoRepositoryImpl implements
		RedirecionamentoRepository {

	@PersistenceContext
	private EntityManager em;

	@Override
	public List<Redirecionamento> findAllBySitio(Sitio sitio) {
		return findAllBySitio(sitio.getId());
	}

	@Override
	public List<Redirecionamento> findAllBySitio(Long id) {
		TypedQuery<Redirecionamento> q = em
				.createQuery(
						"select r from Redirecionamento as r where r.sitio.id = :id order by r.urlAntiga",
						Redirecionamento.class);
		q.setParameter("id", id);
		return q.getResultList();
	}

	@Override
	public boolean exists(Long id) {
		TypedQuery<Long> query = em.createQuery(
				"select count(r.id) from Redirecionamento r where r.id = :id",
				Long.class);
		query.setParameter("id", id);
		return query.getSingleResult() == 1;
	}

	@Override
	@Transactional
	public void delete(Redirecionamento redirecionamento) {
		em.remove(em.contains(redirecionamento) ? redirecionamento : em
				.merge(redirecionamento));
	}

	@Override
	@Transactional
	public Redirecionamento save(Redirecionamento redirecionamento) {
		// novo
		if (redirecionamento.getId() == null) {
			em.persist(redirecionamento);
			return redirecionamento;
		} else {
			return em.merge(redirecionamento);
		}
	}

}
