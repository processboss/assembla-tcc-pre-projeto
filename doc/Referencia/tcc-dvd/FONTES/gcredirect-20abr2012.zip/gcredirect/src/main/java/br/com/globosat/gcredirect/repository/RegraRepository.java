package br.com.globosat.gcredirect.repository;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import br.com.globosat.gcredirect.model.Regra;
import br.com.globosat.gcredirect.model.Usuario;

/*
 * We use @Transactional to make sure the save(…) operation is running in 
 * a transaction and to allow setting the readOnly-flag (at the class level) 
 * for findAll(...), findOne(...). 
 * This causes some performance optimizations inside the persistence provider 
 * as well as on the database level.
 */

/*
 * @Service serves as a specialization of @Component, allowing for 
 * implementation classes to be autodetected through classpath scanning. 
 * What this means is that you could annotate your service-layer 
 * classes with @Component, but by annotating them with @Service instead, 
 * your classes are more properly suited for processing by tools or 
 * associating with aspects, since @Service makes an ideal target for pointcuts.
 */

/**
 * 
 * @author "Marcelo Rezende Módolo"
 *
 */
@Repository
@Transactional(readOnly=true)
public interface RegraRepository  {

	/**
	 * Retorna todas as regras para o usuário.
	 * @param usuario
	 * @return
	 */
	List<Regra> findByUsuario(Usuario usuario);
	
	/**
	 * Retorna todas as regras para o usuário.
	 * @param id
	 * @return
	 */
	List<Regra> findByUsuario(Long id);
	
	/**
	 * Retorna uma regra pelo seu nome.
	 * @param nome
	 * @return
	 */
	Regra findOne(String nome);

	/**
	 * Retorna todas as regras.
	 * @return
	 */
	List<Regra> findAll();

	/**
	 * Encontra uma regra pelo seu ID.
	 * @param id
	 * @return
	 */
	Regra findOne(Long id);

	/**
	 * Atualiza ou salva a regra.
	 * @param regra
	 * @return
	 */
	@Transactional
	Regra save(Regra regra);
	
}
