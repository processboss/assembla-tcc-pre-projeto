package br.com.globosat.gcredirect.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import br.com.globosat.gcredirect.model.Regra;
import br.com.globosat.gcredirect.model.Usuario;

@Repository
@Transactional(readOnly = true)
public class RegraRepositoryImpl implements RegraRepository {

	@PersistenceContext
	private EntityManager em;

	@Override
	public List<Regra> findByUsuario(Usuario usuario) {
		return findByUsuario(usuario.getId());
	}

	@Override
	public List<Regra> findByUsuario(Long id) {
		Assert.notNull(id, "The given id must not be null!");
		TypedQuery<Regra> q = em
				.createQuery(
						"select r from Regra r, Usuario u where u.id = :id and r member of u.regras",
						Regra.class);
		q.setParameter("id", id);
		return q.getResultList();
	}

	@Override
	public Regra findOne(String nome) {
		TypedQuery<Regra> q = em
				.createQuery(
						"select r from Regra r where r.nome  = :nome",
						Regra.class);
		q.setParameter("nome", nome);
		return q.getSingleResult();
	}

	@Override
	public List<Regra> findAll() {
		TypedQuery<Regra> q = em
				.createQuery(
						"select r from Regra as r order by r.nome",
						Regra.class);
		return q.getResultList();
	}

	@Override
	public Regra findOne(Long id) {
		Assert.notNull(id, "The given id must not be null!");
		return em.find(Regra.class, id);
	}

	@Override
	@Transactional
	public Regra save(Regra regra) {
		if (regra.getId() == null) {
			em.persist(regra);
			return regra;
		} else {
			return em.merge(regra);
		}
	}

}
