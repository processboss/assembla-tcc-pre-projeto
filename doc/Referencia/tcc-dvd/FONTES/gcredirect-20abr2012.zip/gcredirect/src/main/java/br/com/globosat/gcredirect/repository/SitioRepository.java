package br.com.globosat.gcredirect.repository;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;

/*
 * We use @Transactional to make sure the save(…) operation is running in 
 * a transaction and to allow setting the readOnly-flag (at the class level) 
 * for findAll(...), findOne(...). 
 * This causes some performance optimizations inside the persistence provider 
 * as well as on the database level.
 */

/*
 * @Service serves as a specialization of @Component, allowing for 
 * implementation classes to be autodetected through classpath scanning. 
 * What this means is that you could annotate your service-layer 
 * classes with @Component, but by annotating them with @Service instead, 
 * your classes are more properly suited for processing by tools or 
 * associating with aspects, since @Service makes an ideal target for pointcuts.
 */

/**
 * 
 * @author "Marcelo Rezende Módolo"
 *
 */
@Repository
@Transactional(readOnly=true)
public interface SitioRepository {

	/**
	 * Retorna todos os sítios associados a um usuário.
	 * @param usuario
	 * @return
	 */
	public abstract List<Sitio> findAllByUsuario(Usuario usuario);
	
	/**
	 * Retorna todos os sítios associados a um usuário.
	 * @param id
	 * @return
	 */
	public abstract List<Sitio> findAllByUsuario(Long id);

	/**
	 * Verifica se o Sítio existe.
	 * @param id
	 * @return
	 */
	public abstract boolean exists(Long id);

	/**
	 * Salva ou atualiza o sítio.
	 * @param sitio
	 * @return
	 */
	@Transactional
	public abstract Sitio save(Sitio sitio);

	/**
	 * Encontra o sítio pelo seu ID.
	 * @param id
	 * @return
	 */
	public abstract Sitio findOne(Long id);

	/**
	 * Encontra todos os sítios.
	 * @return
	 */
	public abstract List<Sitio> findAll();

	/**
	 * Retorna o sítio pela sua sigla.
	 * @param sigla
	 * @return
	 */
	public abstract Sitio findOneBySitioSigla(String sigla);
		
}
