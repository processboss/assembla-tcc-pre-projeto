/**
 * 
 */
package br.com.globosat.gcredirect.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;

/**
 * @author "Marcelo Rezende Módolo"
 *
 */
@Repository
@Transactional(readOnly=true)
public class SitioRepositoryImpl implements SitioRepository {

	@PersistenceContext
	private EntityManager em;
	
	/* (non-Javadoc)
	 * @see br.com.globosat.gcredirect.repository.SitioRepository#findAllByUsuario(br.com.globosat.gcredirect.model.Usuario)
	 */
	@Override
	public List<Sitio> findAllByUsuario(Usuario usuario) {
		return findAllByUsuario(usuario.getId());
	}

	/* (non-Javadoc)
	 * @see br.com.globosat.gcredirect.repository.SitioRepository#findAllByUsuario(java.lang.Long)
	 */
	@Override
	public List<Sitio> findAllByUsuario(Long id) {
		Assert.notNull(id, "The given id must not be null!");
		TypedQuery<Sitio> q = em.createQuery("select s from Sitio s, Usuario u where u.id = :id and s member of u.sitios", Sitio.class);
		q.setParameter("id", id);
		return q.getResultList();
	}

	/* (non-Javadoc)
	 * @see br.com.globosat.gcredirect.repository.SitioRepository#exists(java.lang.Long)
	 */
	@Override
	public boolean exists(Long id) {
		TypedQuery<Long> query = em.createQuery("select count(s.id) from Sitio s where s.id = :id", Long.class);
		query.setParameter("id", id);
		return query.getSingleResult() == 1;
	}

	/* (non-Javadoc)
	 * @see br.com.globosat.gcredirect.repository.SitioRepository#save(br.com.globosat.gcredirect.model.Sitio)
	 */
	@Override
	public Sitio save(Sitio sitio) {
		if (sitio.getId() == null ) {
			em.persist(sitio);
			return sitio;
		} else {
			return em.merge(sitio);
		}
	}

	/* (non-Javadoc)
	 * @see br.com.globosat.gcredirect.repository.SitioRepository#findOne(java.lang.Long)
	 */
	@Override
	public Sitio findOne(Long id) {
		Assert.notNull(id, "The given id must not be null!");	
		return em.find(Sitio.class, id);
	}

	/* (non-Javadoc)
	 * @see br.com.globosat.gcredirect.repository.SitioRepository#findAll()
	 */
	@Override
	public List<Sitio> findAll() {
		TypedQuery<Sitio> q = em.createQuery("select s from Sitio s order by s.sigla", Sitio.class);
		return q.getResultList();
	}

	@Override
	public Sitio findOneBySitioSigla(String sigla) {
		TypedQuery<Sitio> q = em.createQuery("select s from Sitio s where s.sigla = :sigla", Sitio.class);
		q.setParameter("sigla", sigla);
		return q.getSingleResult();
	}

}
