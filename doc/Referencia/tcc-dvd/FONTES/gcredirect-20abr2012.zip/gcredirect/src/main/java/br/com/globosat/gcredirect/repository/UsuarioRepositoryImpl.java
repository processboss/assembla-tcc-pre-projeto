/**
 * 
 */
package br.com.globosat.gcredirect.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;

/**
 * @author "Marcelo Rezende Módolo"
 * 
 */
@Repository
@Transactional(readOnly = true)
public class UsuarioRepositoryImpl implements UsuarioRepository {

	@PersistenceContext
	private EntityManager em;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.globosat.gcredirect.repository.UsuarioRepository#findOne(java.
	 * lang.String)
	 */
	@Override
	public Usuario findOne(String usuario) {
		TypedQuery<Usuario> q = em.createQuery(
				"select u from Usuario u where u.usuario = :usuario",
				Usuario.class);
		q.setParameter("usuario", usuario);
		return q.getSingleResult();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.globosat.gcredirect.repository.UsuarioRepository#findAllBySitio
	 * (br.com.globosat.gcredirect.model.Sitio)
	 */
	@Override
	public List<Usuario> findAllBySitio(Sitio sitio) {
		TypedQuery<Usuario> q = em.createQuery(
				"select u from Usuario u where :sitio in elements(u.sitios)",
				Usuario.class);
		q.setParameter("sitio", sitio);
		return q.getResultList();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.globosat.gcredirect.repository.UsuarioRepository#exists(java.lang
	 * .Long)
	 */
	@Override
	public boolean exists(Long id) {
		TypedQuery<Long> query = em.createQuery(
				"select count(u.id) from Usuario u where u.id = :id",
				Long.class);
		query.setParameter("id", id);
		return query.getSingleResult() == 1;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see br.com.globosat.gcredirect.repository.UsuarioRepository#findAll()
	 */
	@Override
	public List<Usuario> findAll() {
		TypedQuery<Usuario> q = em.createQuery(
				"select u from Usuario u order by u.nome", Usuario.class);
		return q.getResultList();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.globosat.gcredirect.repository.UsuarioRepository#findOne(java.
	 * lang.Long)
	 */
	@Override
	public Usuario findOne(Long id) {
		Assert.notNull(id, "The given id must not be null!");
		return em.find(Usuario.class, id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * br.com.globosat.gcredirect.repository.UsuarioRepository#save(br.com.globosat
	 * .gcredirect.model.Usuario)
	 */
	@Override
	@Transactional
	public Usuario save(Usuario usuario) {
		if (usuario.getId() == null) {
			em.persist(usuario);
			return usuario;
		} else {
			return em.merge(usuario);
		}
	}

}
