package br.com.globosat.gcredirect.security;

import org.springframework.security.authentication.AccountStatusException;

/**
 * GCRedirectAccountStatusException estende AccountStatusException.
 * 
 * @author Marcelo Rezende Módolo
 *
 */
public class GCRedirectAccountStatusException extends AccountStatusException {

	public GCRedirectAccountStatusException(String msg, Throwable t) {
		super(msg, t);
	}

	
	public GCRedirectAccountStatusException(String msg) {
		super(msg);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


}
