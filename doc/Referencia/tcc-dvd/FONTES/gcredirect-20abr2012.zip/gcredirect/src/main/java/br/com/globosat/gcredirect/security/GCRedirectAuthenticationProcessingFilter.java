package br.com.globosat.gcredirect.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * GCRedirectAuthenticationProcessingFilter extends
 * AbstractAuthenticationProcessingFilter para persolalizar a autenticação
 * obtendo a sigla do canal:
 * <p>
 * 
 * siglaCanalParameter: Sigla do canal (opcional)
 * <p>
 * 
 * @author Marcelo Rezende Módolo
 * 
 */
public class GCRedirectAuthenticationProcessingFilter extends
		UsernamePasswordAuthenticationFilter {

	public static final String GCREDIRECT_SECURITY_FORM_SIGLA_CANAL_KEY = "j_gcredirect_sigla_canal";

	private String siglaCanalParameter = GCREDIRECT_SECURITY_FORM_SIGLA_CANAL_KEY;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(GCRedirectAuthenticationProcessingFilter.class);

	public GCRedirectAuthenticationProcessingFilter() {
		super();
	}

	@Override
	public Authentication attemptAuthentication(HttpServletRequest request,
			HttpServletResponse response) throws AuthenticationException {

		final boolean postOnly = true;
		if (postOnly && !request.getMethod().equals("POST")) {
			throw new AuthenticationServiceException(
					"Authentication method not supported: "
							+ request.getMethod());
		}
		String usuario = super.obtainUsername(request);
		String senha = super.obtainPassword(request);
		String siglaCanal = obtainSiglaCanal(request);

		if (usuario == null) {
			usuario = "";
		}

		if (senha == null) {
			senha = "";
		}

		if (siglaCanal == null) {
			siglaCanal = "";
		}

		usuario = usuario.trim();

		GCRedirectAuthenticationToken authRequest = new GCRedirectAuthenticationToken(
				usuario, senha, siglaCanal);

		// Allow subclasses to set the "details" property
		setDetails(request, authRequest);

		if (LOGGER.isDebugEnabled()) {
			StringBuilder sb = new StringBuilder("\n\n************************************************************\n\n");
			
			sb.append("\t");
			sb.append(authRequest.toString());
			
			sb.append("\n\n************************************************************\n\n");
			LOGGER.debug(sb.toString());			
		}
		
		return this.getAuthenticationManager().authenticate(authRequest);
	}

	protected String obtainSiglaCanal(HttpServletRequest request) {
		return request.getParameter(siglaCanalParameter);
	}

	/**
	 * @return the siglaCanalParameter
	 */
	public String getSiglaCanalParameter() {
		return siglaCanalParameter;
	}

	/**
	 * @param siglaCanalParameter
	 *            the siglaCanalParameter to set
	 */
	public void setSiglaCanalParameter(String siglaCanalParameter) {
		this.siglaCanalParameter = siglaCanalParameter;
	}

}
