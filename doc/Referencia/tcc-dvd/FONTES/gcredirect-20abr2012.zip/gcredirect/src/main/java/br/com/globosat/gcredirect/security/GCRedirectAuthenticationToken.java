package br.com.globosat.gcredirect.security;

import java.util.Collection;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

/**
 * GCRedirectAuthenticationToken estende UsernamePasswordAuthenticationToken
 * e permite que o usuário seja autenticado também pela sigla do canal ao
 * qual pertence.<p>
 * A sigla do canal é opcional.
 * 
 * @author modolo
 * 
 */
public class GCRedirectAuthenticationToken extends
		UsernamePasswordAuthenticationToken {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String siglaCanal;

	/**
	 * 
	 * @param principal
	 *            O sujeito (usuário) a ser autenticado
	 * @param credentials
	 *            A senha
	 * @param siglaCanal
	 *            A sigla do canal
	 */
	public GCRedirectAuthenticationToken(String principal, String credentials,
			String siglaCanal) {
		super(principal, credentials);
		if (siglaCanal == null) {
			this.siglaCanal = "";
		} else {
			this.siglaCanal = siglaCanal.trim();
		}
	}

	
	public GCRedirectAuthenticationToken(Object principal, Object credentials,
			Collection<? extends GrantedAuthority> authorities) {
		super(principal, credentials, authorities);
	}


	public GCRedirectAuthenticationToken(Object principal, Object credentials) {
		super(principal, credentials);
	}


	public void setSiglaCanal(String siglaCanal) {
		this.siglaCanal = siglaCanal;
	}

	public String getSiglaCanal() {
		return siglaCanal;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GCRedirectAuthenticationToken [siglaCanal=" + siglaCanal
				+ ", getCredentials()=" + getCredentials()
				+ ", getPrincipal()=" + getPrincipal() + "]";
	}



}
