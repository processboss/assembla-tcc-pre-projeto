package br.com.globosat.gcredirect.security;

import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.security.authentication.encoding.PasswordEncoder;

/**
 * Utility methods.
 * 
 * @author "Marcelo Rezende Módolo"
 *
 */
public class GCRedirectMD5PasswordEncoder {

	private GCRedirectMD5PasswordEncoder() {}
	
	/**
	 * Encodes the specified raw password with MD5 specific algorithm.
	 * @param password to encode
	 * @return encoded password
	 */
	public static String encodePassword(String password) {
		PasswordEncoder encoder = new Md5PasswordEncoder();
		password = encoder.encodePassword(password, null);
		return password;
	}
	
}
