package br.com.globosat.gcredirect.security;

import java.io.Serializable;

/**
 * Models core site information.
 * <p>
 * Implemented with value object semantics (immutable after construction, like a <code>String</code>).
 * <br>
 * Unlike the class <code>Sitio</code>, carries only the information necessary for user authentication.
 * <br>
 * Avoiding overload the session with heavy objects.
 * 
 * @author "Marcelo Rezende Módolo"
 *
 */
public class GCRedirectSite implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8322628462489173659L;
	private final Long id;
	private final String acronym;
	private final String name;
	
	/**
	 * @param id
	 * @param acronym
	 * @param name
	 */
	public GCRedirectSite(Long id, String acronym, String name) {
		super();
		this.id = id;
		this.acronym = acronym;
		this.name = name;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @return the acronym
	 */
	public String getAcronym() {
		return acronym;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((acronym == null) ? 0 : acronym.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GCRedirectSite other = (GCRedirectSite) obj;
		if (acronym == null) {
			if (other.acronym != null)
				return false;
		} else if (!acronym.equals(other.acronym))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "GCRedirectSite [id=" + id + ", acronym=" + acronym + ", name="
				+ name + "]";
	}
	
	
}
