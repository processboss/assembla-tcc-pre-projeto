/**
 * 
 */
package br.com.globosat.gcredirect.security;

import java.util.Collections;
import java.util.List;

/**
 * Utility methods.
 * 
 * @author Marcelo Rezende Módolo
 *
 */
public abstract class GCRedirectSitelUtils {
	public static final List<GCRedirectSite> NO_SITES = Collections.emptyList();
}
