/**
 * 
 */
package br.com.globosat.gcredirect.security;

import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.util.Assert;

/**
 * Models core user information retrieved by a {@link GCRedirectUserDetailsService}.
 * <p>
 * Implemented with value object semantics (immutable after construction, like a <code>String</code>).
 * Add full name, email, telephone and list of sites to which the user is associated.
 * 
 * @author Marcelo Rezende Módolo
 * 
 */
public class GCRedirectUserDetails extends User {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final Long id;
	private final String fullName;
	private final String email;
	private final String fone;
	private final Set<GCRedirectSite> sites;

	/**
	 * @param id
	 * @param fullName
	 * @param email
	 * @param username
	 * @param password
	 * @param enabled
	 * @param accountNonExpired
	 * @param credentialsNonExpired
	 * @param accountNonLocked
	 * @param authorities
	 * @param sites
	 */
	public GCRedirectUserDetails(Long id, String fullName, String email, String fone,
			String username, String password, boolean enabled,
			boolean accountNonExpired, boolean credentialsNonExpired,
			boolean accountNonLocked,
			Collection<? extends GrantedAuthority> authorities,
			Collection<GCRedirectSite> sites) {
		super(username, password, enabled, accountNonExpired,
				credentialsNonExpired, accountNonLocked, authorities);
		
		if (((fullName == null) || "".equals(fullName)) || (email == null)
				|| "".equals(email) || (fone == null) || "".equals(fone)) {
			throw new IllegalArgumentException(
					"Cannot pass null or empty values to constructor");
		}
		this.id = id;
		this.fullName = fullName;
		this.email = email;
		this.fone = fone;
		this.sites = Collections.unmodifiableSet(sortSites(sites));
	}

	/**
	 * @param fullName
	 * @param email
	 * @param username
	 * @param password
	 * @param authorities
	 * @param sites
	 */
	public GCRedirectUserDetails(String fullName, String email, String fone,
			String username, String password,
			Collection<? extends GrantedAuthority> authorities,
			Collection<GCRedirectSite> sites) {
		super(username, password, authorities);
		if (((fullName == null) || "".equals(fullName)) || (email == null)
				|| "".equals(email) || (fone == null) || "".equals(fone)) {
			throw new IllegalArgumentException(
					"Cannot pass null or empty values to constructor");
		}
		this.id = null;
		this.fullName = fullName;
		this.email = email;
		this.fone = fone;
		this.sites = Collections.unmodifiableSet(sortSites(sites));
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	
	
	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @return the fone
	 */
	public String getFone() {
		return fone;
	}
	
	/**
	 * @return the sites
	 */
	public Set<GCRedirectSite> getSites() {
		return sites;
	}

	private static SortedSet<GCRedirectSite> sortSites(
			Collection<GCRedirectSite> sites) {
		Assert.notNull(sites, "Cannot pass a null GCRedirectSite collection");
		SortedSet<GCRedirectSite> sortedSites = new TreeSet<GCRedirectSite>(
				new GCRedirectSiteComparator());
		for (GCRedirectSite site : sites) {
			Assert.notNull(site,
					"GCRedirectSite list cannot contain any null elements");
			sortedSites.add(site);
		}
		return sortedSites;
	}

	private static class GCRedirectSiteComparator implements
			Comparator<GCRedirectSite>, Serializable {

		private static final long serialVersionUID = 1L;

		public int compare(GCRedirectSite s1, GCRedirectSite s2) {
			if (s2.getAcronym() == null) {
				return -1;
			}
			if (s1.getAcronym() == null) {
				return 1;
			}
			return s1.getAcronym().compareTo(s2.getAcronym());
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(super.toString()).append(": ");
		sb.append("ID: ").append(this.id).append("; ");
		sb.append("FullName: ").append(this.fullName).append("; ");
		sb.append("E-mail: ").append(this.email).append("; ");
		sb.append("Fone: ").append(this.fone).append("; ");
		if (!sites.isEmpty()) {
			sb.append("Related Sites: ");
			boolean first = true;
			for (GCRedirectSite site : sites) {
				if (!first) {
					sb.append(",");
				}
				first = false;
				sb.append(site);
			}
		} else {
			sb.append("Not associated with any site");
		}
		return sb.toString();
	}

}
