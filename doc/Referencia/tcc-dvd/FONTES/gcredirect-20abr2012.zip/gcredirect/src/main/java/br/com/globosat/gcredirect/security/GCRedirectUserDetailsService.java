package br.com.globosat.gcredirect.security;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.core.userdetails.jdbc.JdbcDaoImpl;

/*
 //Obter detalhes do usuário pelo usuário
 SELECT 
 u.senha, 
 u.nome, 
 u.usuario
 FROM 
 usuario u 
 WHERE 
 u.usuario = 'modolo';

 //Obter "roles" do usuário pelo usuário
 SELECT 
 r.nome
 FROM 
 regra r, 
 regra_usuario ru, 
 usuario u
 WHERE 
 (r.id = ru.id_regra AND
 u.id = ru.id_usuario) AND
 u.usuario = 'modolo';

 //Verificar se o usuário percente ao canal
 SELECT 
 COUNT(c.sigla) as "count_canal"
 FROM 
 canal c, 
 canal_usuario cu, 
 usuario u
 WHERE 
 (c.id = cu.id_canal AND u.id = cu.id_usuario ) AND
 (u.usuario = 'modolo' AND c.sigla = 'SPO');

 //Obter "canais" aos quais o usuário pertence pelo usuário
 SELECT 
 c.sigla
 FROM 
 usuario u, 
 canal_usuario cu, 
 canal c
 WHERE 
 u.id = cu.id_usuario AND
 c.id = cu.id_canal AND
 u.usuario = 'modolo'
 */

/**
 * GCRedirectUserDetailsService extends <code>JdbcDaoImpl</code> customizing
 * queries for users, authorities and sites.
 * 
 * @author Marcelo Rezende Módolo
 * 
 */
public class GCRedirectUserDetailsService extends JdbcDaoImpl {

	public static final String DEF_USERS_BY_USERNAME_QUERY = "SELECT u.id as id, u.nome as fullName, "
			+ "u.email as email, u.senha as password, u.usuario as username, "
			+ "u.ativo as enabled, u.telefone as fone FROM usuario u WHERE u.usuario = ?";

	public static final String DEF_AUTHORITIES_BY_USERNAME_QUERY = "SELECT u.usuario as username, "
			+ "r.nome as authority FROM usuario u, regra r, "
			+ "regra_usuario ru WHERE (r.id = ru.id_regra AND "
			+ "ru.id_usuario = u.id) AND u.usuario = ?";

	public static final String DEF_SITES_BY_USERNAME_QUERY = "SELECT u.usuario as username, "
			+ "s.id as id, s.sigla as acronym, s.nome as name FROM sitio s, sitio_usuario su, "
			+ "usuario u WHERE ( s.id = su.id_sitio AND "
			+ "su.id_usuario = u.id ) AND u.usuario = ?";

	private static final Logger LOGGER = LoggerFactory
			.getLogger(GCRedirectUserDetailsService.class);

	private String sitesByUsernameQuery;

	/**
	 * Construtor default
	 */
	public GCRedirectUserDetailsService() {
		super();
		setUsersByUsernameQuery(DEF_USERS_BY_USERNAME_QUERY);
		setAuthoritiesByUsernameQuery(DEF_AUTHORITIES_BY_USERNAME_QUERY);
		this.sitesByUsernameQuery = DEF_SITES_BY_USERNAME_QUERY;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.core.userdetails.jdbc.JdbcDaoImpl#
	 * loadUserByUsername(java.lang.String)
	 */
	@Override
	public UserDetails loadUserByUsername(String username)
			throws UsernameNotFoundException {

		List<UserDetails> users = loadUsersByUsername(username);
		if (users.size() == 0) {
			LOGGER.debug("A consulta não retornou resultados para '" + username
					+ "'");

			throw new UsernameNotFoundException(messages.getMessage(
					"JdbcDaoImpl.notFound", new Object[] { username },
					"usuário {0} não encontrado"));
		}

		UserDetails user = users.get(0);

		Set<GrantedAuthority> dbAuthsSet = new HashSet<GrantedAuthority>();

		if (getEnableAuthorities()) {
			dbAuthsSet.addAll(loadUserAuthorities(user.getUsername()));
		}

		if (getEnableGroups()) {
			dbAuthsSet.addAll(loadGroupAuthorities(user.getUsername()));
		}

		List<GrantedAuthority> dbAuths = new ArrayList<GrantedAuthority>(
				dbAuthsSet);

		addCustomAuthorities(user.getUsername(), dbAuths);

		if (dbAuths.size() == 0) {
			LOGGER.debug("User '" + username
					+ "' has no authority and will be treated as 'not found'");

			throw new UsernameNotFoundException(messages.getMessage(
					"JdbcDaoImpl.noAuthority", new Object[] { username },
					"User {0} has no authority"));
		}

		Set<GCRedirectSite> dbSitesSet = new HashSet<GCRedirectSite>();

		dbSitesSet.addAll(loadSites(username));

		List<GCRedirectSite> dbSites = new ArrayList<GCRedirectSite>(dbSitesSet);

		if (dbSites.size() == 0) {

			LOGGER.debug("User '"
					+ username
					+ "' is not associated with any site and will be treated as 'not found'");

			throw new UsernameNotFoundException(messages.getMessage(
					"JdbcDaoImpl.noAuthority", new Object[] { username },
					"User {0} is not associated with any site"));
		}

		final GCRedirectUserDetails details = createUserDetails(username,
				(GCRedirectUserDetails) user, dbAuths, dbSites);

		if (LOGGER.isDebugEnabled()) {
			StringBuilder sb = new StringBuilder(
					"\n\n************************************************************\n\n");
			sb.append("\t");
			sb.append(details.toString());
			for (GrantedAuthority a : details.getAuthorities()) {
				sb.append("\n\t\tGrantedAuthority : ").append(a.getAuthority());
			}
			for (GCRedirectSite c : details.getSites()) {
				sb.append("\n\t\tGCRedirectSite : ").append(c);
			}
			sb.append("\n\n************************************************************\n\n");
			LOGGER.debug(sb.toString());
		}

		return details;
	}

	/**
	 * @return the sitesByUsernameQuery
	 */
	public String getSitesByUsernameQuery() {
		return sitesByUsernameQuery;
	}

	/**
	 * @param sitesByUsernameQuery
	 *            the sitesByUsernameQuery to set
	 */
	public void setSitesByUsernameQuery(String sitesByUsernameQuery) {
		this.sitesByUsernameQuery = sitesByUsernameQuery;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.core.userdetails.jdbc.JdbcDaoImpl#
	 * loadUsersByUsername(java.lang.String)
	 */
	@Override
	protected List<UserDetails> loadUsersByUsername(String username) {

		return getJdbcTemplate().query(getUsersByUsernameQuery(),
				new String[] { username }, new RowMapper<UserDetails>() {
					public GCRedirectUserDetails mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						Long id = rs.getLong("id");
						String fullName = rs.getString("fullName");
						String email = rs.getString("email");
						String password = rs.getString("password");
						String username = rs.getString("username");
						boolean enabled = rs.getBoolean("enabled");
						String fone = rs.getString("fone");
						return new GCRedirectUserDetails(id, fullName, email,
								fone, username, password, enabled, true, true,
								true, AuthorityUtils.NO_AUTHORITIES,
								GCRedirectSitelUtils.NO_SITES);
					}

				});
	}

	/*
	 * Retorna a lista de sítios aos quais o usuário pertence.
	 */
	protected List<GCRedirectSite> loadSites(String username) {
		return getJdbcTemplate().query(sitesByUsernameQuery,
				new String[] { username }, new RowMapper<GCRedirectSite>() {
					public GCRedirectSite mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						Long id = rs.getLong("id");
						String acronym = rs.getString("acronym");
						String name = rs.getString("name");
						return new GCRedirectSite(id, acronym, name);
					}
				});
	}

	private GCRedirectUserDetails createUserDetails(String username,
			GCRedirectUserDetails userFromUserQuery,
			List<GrantedAuthority> combinedAuthorities,
			List<GCRedirectSite> sites) {

		String returnUsername = userFromUserQuery.getUsername();

		if (!isUsernameBasedPrimaryKey()) {
			returnUsername = username;
		}

		final GCRedirectUserDetails user = new GCRedirectUserDetails(
				userFromUserQuery.getId(), userFromUserQuery.getFullName(),
				userFromUserQuery.getEmail(), userFromUserQuery.getFone(),
				returnUsername, userFromUserQuery.getPassword(),
				userFromUserQuery.isEnabled(),
				userFromUserQuery.isAccountNonExpired(),
				userFromUserQuery.isCredentialsNonExpired(),
				userFromUserQuery.isAccountNonLocked(), combinedAuthorities,
				sites);

		return user;
	}
}
