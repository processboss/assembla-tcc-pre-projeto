package br.com.globosat.gcredirect.service;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.springframework.stereotype.Service;

@Service
public abstract class AbstractService<T> {

	private static final SimpleDateFormat FORMATO_DATA = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
		
	protected  void auditaSalvar(Logger logger, T entidade) {
		final StringBuilder sb = new StringBuilder("\n[SALVANDO] : ");
		sb.append(entidade.toString()).append(" [")
		.append( FORMATO_DATA.format(new Date()) ).append("]");
		logger.info(sb.toString());
	}
	
	protected  void auditaExcluir(Logger logger, T entidade) {
		final StringBuilder sb = new StringBuilder("\n[EXCLUINDO] : ");
		sb.append(entidade.toString()).append(" [")
		.append( FORMATO_DATA.format(new Date()) ).append("]");
		logger.info(sb.toString());
	}
	
}
