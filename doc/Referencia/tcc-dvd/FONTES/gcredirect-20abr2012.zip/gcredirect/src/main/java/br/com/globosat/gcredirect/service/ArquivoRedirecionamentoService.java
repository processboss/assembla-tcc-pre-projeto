package br.com.globosat.gcredirect.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.globosat.gcredirect.model.Sitio;

/*
 * We use @Transactional to make sure the save(…) operation is running in 
 * a transaction and to allow setting the readOnly-flag (at the class level) 
 * for findAll(...), findOne(...). 
 * This causes some performance optimizations inside the persistence provider 
 * as well as on the database level.
 */

/*
 * @Service serves as a specialization of @Component, allowing for 
 * implementation classes to be autodetected through classpath scanning. 
 * What this means is that you could annotate your service-layer 
 * classes with @Component, but by annotating them with @Service instead, 
 * your classes are more properly suited for processing by tools or 
 * associating with aspects, since @Service makes an ideal target for pointcuts.
 */

/**
 * Classe de serviços para criação dos arquivos de redirecionamento.
 * 
 * @author "Marcelo Rezende Módolo"
 *
 */
@Service
@Transactional(readOnly = true)
public interface ArquivoRedirecionamentoService {

	/**
	 * Retorna uma lista de strings representando as linhas<br>
	 * do arquivo de redirecionamento no formato:<br>
	 * Redirect STATUS /URL_ANTIGA http://URL_SITIO/URL_NOVA 
	 * @param sitio
	 * @return
	 */
	public abstract List<String> findAll(Sitio sitio);
	
	/**
	 * Gera e grava o arquivo de redirecionamentos.
	 * 
	 * @param sitio
	 */
	public abstract boolean gerarArquivo(Sitio sitio);
	
	
}
