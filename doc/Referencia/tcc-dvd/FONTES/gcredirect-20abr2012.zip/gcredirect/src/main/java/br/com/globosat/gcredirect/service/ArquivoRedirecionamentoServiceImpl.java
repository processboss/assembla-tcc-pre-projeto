package br.com.globosat.gcredirect.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.globosat.gcredirect.model.Redirecionamento;
import br.com.globosat.gcredirect.model.Sitio;

/*
 * We use @Transactional to make sure the save(…) operation is running in 
 * a transaction and to allow setting the readOnly-flag (at the class level) 
 * for findAll(...), findOne(...). 
 * This causes some performance optimizations inside the persistence provider 
 * as well as on the database level.
 */

/*
 * @Service serves as a specialization of @Component, allowing for 
 * implementation classes to be autodetected through classpath scanning. 
 * What this means is that you could annotate your service-layer 
 * classes with @Component, but by annotating them with @Service instead, 
 * your classes are more properly suited for processing by tools or 
 * associating with aspects, since @Service makes an ideal target for pointcuts.
 */

/**
 * 
 * @author "Marcelo Rezende Módolo"
 * 
 */
@Service
@Transactional(readOnly = true)
public class ArquivoRedirecionamentoServiceImpl implements
		ArquivoRedirecionamentoService {

	private static final SimpleDateFormat FORMATO_DATA = new SimpleDateFormat(
			"dd-MM-yy-hh-mm-ss");

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ArquivoRedirecionamentoServiceImpl.class);

	@Autowired
	private RedirecionamentoService redirecionamentoService;

	@Override
	public List<String> findAll(Sitio sitio) {
		final List<String> linhas = new ArrayList<String>();
		final List<Redirecionamento> rs = redirecionamentoService
				.findAllBySitio(sitio);
		for (Redirecionamento r : rs) {
			final StringBuilder sb = new StringBuilder("Redirect\t");
			sb.append(r.getStatus().toString()).append("\t").append("/")
					.append(r.getUrlAntiga()).append("\t").append("http://")
					.append(sitio.getUrlSitio()).append("/")
					.append(r.getUrlNova());
			linhas.add(sb.toString());
		}
		LOGGER.debug(linhas.size() + "# retornadas");
		return linhas;
	}

	@Override
	public boolean gerarArquivo(Sitio sitio) {
		
		if (renomerArquivoAnterior(sitio)) {
			LOGGER.debug("Arquivo renomeado: " + sitio.getArquivoRedirecionamento());
			return escreveArquivo(sitio);
		}

		return false;
	}

	private boolean renomerArquivoAnterior(Sitio sitio) {
		// SIGLA_SITIO-REDIRECT-DIA-MES-ANO-HORA-MINUTO-SS.backup

		final String data = FORMATO_DATA.format(new Date());

		final File arquivoRenomeado = new File(
				sitio.getCaminhoArquivoRedirecionamento(), sitio.getSigla()
						+ "-REDIRECT-" + data + ".backup");
		
		LOGGER.debug(arquivoRenomeado.toString());
		
		final File arquivoOriginal = new File(
				sitio.getCaminhoArquivoRedirecionamento(),
				sitio.getArquivoRedirecionamento());
		
		LOGGER.debug(arquivoOriginal.toString());
		
		final boolean renomeado = arquivoOriginal.renameTo(arquivoRenomeado);

		if (!renomeado) {
			throw new ErroGravacaoException(
					"Não foi possivel renomear o arquivo "
							+ arquivoRenomeado.toString());
			
		}
		return renomeado;

	}

	private boolean escreveArquivo(Sitio sitio) {
		boolean salvo = false;
		
		final File arquivo = new File(
				sitio.getCaminhoArquivoRedirecionamento(),
				sitio.getArquivoRedirecionamento());

		final List<String> linhas = findAll(sitio);

		Writer out = null;
		try {
			out = new OutputStreamWriter(new FileOutputStream(arquivo, false));			
			for (String l : linhas) {
				out.write(l);
				out.write("\n");
			}
		} catch (FileNotFoundException e) {
			LOGGER.error("Arquivo não encontrado", e);
			throw new ErroGravacaoException("Arquivo não encontrado "
					+ arquivo.getName());
		} catch (IOException e) {
			LOGGER.error("Erro de I/O", e);
			throw new ErroGravacaoException("Erro de I/O "
					+ arquivo.getName());
		} finally {
			if (null != out) {
				try {
					out.flush();
					out.close();
					salvo = true;
				} catch (IOException e) {
					LOGGER.error("Erro de I/O", e);
					throw new ErroGravacaoException("Erro Flush/Close "
							+ arquivo.getName());
				}

			}
		}		
		return salvo;
	}
}
