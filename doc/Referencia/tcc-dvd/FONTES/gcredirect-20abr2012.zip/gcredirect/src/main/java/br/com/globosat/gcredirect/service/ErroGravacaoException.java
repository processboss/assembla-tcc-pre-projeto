package br.com.globosat.gcredirect.service;

public class ErroGravacaoException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public ErroGravacaoException() {
		super();
	}

	/**
	 * @param message
	 * @param cause
	 */
	public ErroGravacaoException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public ErroGravacaoException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public ErroGravacaoException(Throwable cause) {
		super(cause);
	}
	
}
