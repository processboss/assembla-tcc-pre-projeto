package br.com.globosat.gcredirect.service;

/*
 * We use @Transactional to make sure the save(…) operation is running in 
 * a transaction and to allow setting the readOnly-flag (at the class level) 
 * for findAll(...), findOne(...). 
 * This causes some performance optimizations inside the persistence provider 
 * as well as on the database level.
 */

/*
 * @Service serves as a specialization of @Component, allowing for 
 * implementation classes to be autodetected through classpath scanning. 
 * What this means is that you could annotate your service-layer 
 * classes with @Component, but by annotating them with @Service instead, 
 * your classes are more properly suited for processing by tools or 
 * associating with aspects, since @Service makes an ideal target for pointcuts.
 */

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.globosat.gcredirect.model.HistoricoRedirecionamento;
import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;
import br.com.globosat.gcredirect.repository.HistoricoRedirecionamentoRepository;

/**
 * 
 * @author "Marcelo Rezende Módolo"
 *
 */
@Service
@Transactional(readOnly = true)
public class HistoricoRedirecionamentoServiceImpl extends
		AbstractService<HistoricoRedirecionamento> implements
		HistoricoRedirecionamentoService {

	@Autowired
	private HistoricoRedirecionamentoRepository repository;
	
	@Override
	public List<HistoricoRedirecionamento> findAllByUsuario(Usuario usuario) {
		return repository.findAllByUsuario(usuario);
	}

	@Override
	public List<HistoricoRedirecionamento> findAllByUsuario(Long id) {
		return repository.findAllByUsuario(id);
	}

	@Override
	public List<HistoricoRedirecionamento> findAllBySitio(Sitio sitio) {
		return repository.findAllBySitio(sitio);
	}

	@Override
	public List<HistoricoRedirecionamento> findAllBySitio(Long id) {
		return repository.findAllBySitio(id);
	}

	@Override
	public List<HistoricoRedirecionamento> findAllBySitioUrlNova(Sitio sitio,
			String urlNova) {
		return repository.findAllBySitioUrlNova(sitio, urlNova);
	}

	@Override
	public List<HistoricoRedirecionamento> findAllBySitioUrlAntiga(Sitio sitio,
			String urlAntiga) {
		return repository.findAllBySitioUrlAntiga(sitio, urlAntiga);
	}

	@Override
	public List<HistoricoRedirecionamento>  findByRedirecionamentoId(Long id) {
		return repository.findByRedirecionamentoId(id);
	}

}
