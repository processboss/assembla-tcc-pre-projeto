package br.com.globosat.gcredirect.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.globosat.gcredirect.model.Redirecionamento;
import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;

/*
 * We use @Transactional to make sure the save(…) operation is running in 
 * a transaction and to allow setting the readOnly-flag (at the class level) 
 * for findAll(...), findOne(...). 
 * This causes some performance optimizations inside the persistence provider 
 * as well as on the database level.
 */

/*
 * @Service serves as a specialization of @Component, allowing for 
 * implementation classes to be autodetected through classpath scanning. 
 * What this means is that you could annotate your service-layer 
 * classes with @Component, but by annotating them with @Service instead, 
 * your classes are more properly suited for processing by tools or 
 * associating with aspects, since @Service makes an ideal target for pointcuts.
 */

/**
 * Classe de serviço para os redirecionamentos.
 * @author "Marcelo Rezende Módolo"
 *
 */
@Service
@Transactional(readOnly = true)
public interface RedirecionamentoService {

	/**
	 * Retorna todos os redirecionamentos de um sítio.
	 * @param sitio
	 * @return
	 */
	public abstract List<Redirecionamento> findAllBySitio(Sitio sitio);
	
	/**
	 * Cria um novo redirecionamento.<br>
	 * Ao ser criado um redirecionamento, o mesmo é registrado no histórico.
	 * 
	 * @param redirecionamento O redirecionamento a ser criado
	 * @param autor O usuário autor do redirecionamento
	 * @return
	 */
	@Transactional
	public abstract Redirecionamento criarNovo(Redirecionamento redirecionamento, Usuario autor);
	
	/**
	 * Exclui um redirecionamento.<br>
	 * Ao ser excluído, o mesmo é registrado no histórico.
	 * @param redirecionamento O redirecionamento a ser excluído
	 * @param autor O usuário autor da exclusão
	 */
	@Transactional
	public abstract void excluir(Redirecionamento redirecionamento, Usuario autor);
	
}
