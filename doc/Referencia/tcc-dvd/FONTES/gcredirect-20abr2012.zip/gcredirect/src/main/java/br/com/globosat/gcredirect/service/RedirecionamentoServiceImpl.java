package br.com.globosat.gcredirect.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import br.com.globosat.gcredirect.model.HistoricoRedirecionamento;
import br.com.globosat.gcredirect.model.HistoricoRedirecionamento.Acao;
import br.com.globosat.gcredirect.model.Redirecionamento;
import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;
import br.com.globosat.gcredirect.repository.HistoricoRedirecionamentoRepository;
import br.com.globosat.gcredirect.repository.RedirecionamentoRepository;
import br.com.globosat.gcredirect.repository.SitioRepository;
import br.com.globosat.gcredirect.repository.UsuarioRepository;

/*
 * We use @Transactional to make sure the save(…) operation is running in 
 * a transaction and to allow setting the readOnly-flag (at the class level) 
 * for findAll(...), findOne(...). 
 * This causes some performance optimizations inside the persistence provider 
 * as well as on the database level.
 */

/*
 * @Service serves as a specialization of @Component, allowing for 
 * implementation classes to be autodetected through classpath scanning. 
 * What this means is that you could annotate your service-layer 
 * classes with @Component, but by annotating them with @Service instead, 
 * your classes are more properly suited for processing by tools or 
 * associating with aspects, since @Service makes an ideal target for pointcuts.
 */

/**
 * 
 * @author "Marcelo Rezende Módolo"
 * 
 */
@Service
@Transactional(readOnly = true)
public class RedirecionamentoServiceImpl extends
		AbstractService<HistoricoRedirecionamento> implements RedirecionamentoService {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(RedirecionamentoServiceImpl.class);

	@Autowired
	private RedirecionamentoRepository repository;

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Autowired
	private HistoricoRedirecionamentoRepository historicoRedirecionamentoRepository;

	@Autowired
	private SitioRepository sitioRepository;

	@Override
	public List<Redirecionamento> findAllBySitio(Sitio sitio) {
		return repository.findAllBySitio(sitio);
	}

	@Override
	@Transactional
	public Redirecionamento criarNovo(Redirecionamento redirecionamento, Usuario autor) {

		Assert.notNull(redirecionamento, "Redirecionamento não pode ser nulo");

		// Usuário deve existir...
		Assert.notNull(autor, "Autor não pode ser nulo");
		Assert.isTrue(usuarioRepository.exists(autor.getId()),
				"Autor não encontrado");

		// Sítio deve existir...
		Assert.isTrue(
				sitioRepository.exists(redirecionamento.getSitio().getId()),
				"Sítio não encontrado");

		// Um redirecionamento não pode ser salvo mais de uma vez...
		Assert.isNull(redirecionamento.getId(), "Sítio não encontrado");

		redirecionamento = repository.save(redirecionamento);

		// Toda operação de criação deve ser registrada em histórico...
		HistoricoRedirecionamento hr = new HistoricoRedirecionamento(
				redirecionamento, autor, Acao.CRIAR);

		hr = historicoRedirecionamentoRepository.save(hr);

		auditaSalvar(LOGGER, hr);
		
		return redirecionamento;
	}

	@Override
	@Transactional
	public void excluir(Redirecionamento redirecionamento, Usuario autor) {
		Assert.notNull(redirecionamento, "Redirecionamento não pode ser nulo");

		// Usuário deve existir...
		Assert.notNull(autor, "Autor não pode ser nulo");
		Assert.isTrue(usuarioRepository.exists(autor.getId()),
				"Autor não encontrado");

		// Sítio deve existir...
		Assert.isTrue(
				sitioRepository.exists(redirecionamento.getSitio().getId()),
				"Sítio não encontrado");

		Sitio sitio = redirecionamento.getSitio();
		Assert.notNull(sitio, "Sítio não pode ser nulo");
		
		// Um redirecionamento não pode ser excluído mais de uma vez...
		Assert.isTrue(repository.exists(redirecionamento.getId()), "Redirecionamento já foi excluído");

		// Toda operação de exclusão deve ser registrada em histórico...	
		HistoricoRedirecionamento hr = new HistoricoRedirecionamento(
				redirecionamento, autor, Acao.EXCLUIR);

		hr = historicoRedirecionamentoRepository.save(hr);
		repository.delete(redirecionamento);

		auditaExcluir(LOGGER, hr);
	}

}
