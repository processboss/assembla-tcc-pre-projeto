package br.com.globosat.gcredirect.service;

import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.globosat.gcredirect.model.Regra;
import br.com.globosat.gcredirect.model.Usuario;
import br.com.globosat.gcredirect.repository.RegraRepository;

/*
 * We use @Transactional to make sure the save(…) operation is running in 
 * a transaction and to allow setting the readOnly-flag (at the class level) 
 * for findAll(...), findOne(...). 
 * This causes some performance optimizations inside the persistence provider 
 * as well as on the database level.
 */

/*
 * @Service serves as a specialization of @Component, allowing for 
 * implementation classes to be autodetected through classpath scanning. 
 * What this means is that you could annotate your service-layer 
 * classes with @Component, but by annotating them with @Service instead, 
 * your classes are more properly suited for processing by tools or 
 * associating with aspects, since @Service makes an ideal target for pointcuts.
 */

/**
 * 
 * @author "Marcelo Rezende Módolo"
 *
 */
@Service
@Transactional(readOnly = true)
public class RegraServiceImpl extends AbstractService<Regra> implements RegraService{

	private static final Logger LOGGER = LoggerFactory.getLogger(RegraServiceImpl.class);
	
	@Autowired
	private RegraRepository regraRepository;
	
	@Override
	public List<Regra> findAll() {
		return regraRepository.findAll();
	}

	@Override
	public Regra findOne(Long id) {
		return regraRepository.findOne(id);
	}

	@Override
	public List<Regra> findByUsuario(Usuario usuario) {
		return regraRepository.findByUsuario(usuario);
	}

	@Override
	public List<Regra> findByUsuario(Long id) {
		return regraRepository.findByUsuario(id);
	}

	@Override
	@Transactional
	public Regra save(Regra regra) {
		auditaSalvar(LOGGER, regra); //Auditoria
		return regraRepository.save(regra);
	}

	@Override
	public Regra findOne(String nome) {
		return regraRepository.findOne(nome);
	}


}
