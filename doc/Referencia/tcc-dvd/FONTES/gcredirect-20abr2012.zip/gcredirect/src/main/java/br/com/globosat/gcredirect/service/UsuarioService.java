package br.com.globosat.gcredirect.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;

/*
 * We use @Transactional to make sure the save(…) operation is running in 
 * a transaction and to allow setting the readOnly-flag (at the class level) 
 * for findAll(...), findOne(...). 
 * This causes some performance optimizations inside the persistence provider 
 * as well as on the database level.
 */

/*
 * @Service serves as a specialization of @Component, allowing for 
 * implementation classes to be autodetected through classpath scanning. 
 * What this means is that you could annotate your service-layer 
 * classes with @Component, but by annotating them with @Service instead, 
 * your classes are more properly suited for processing by tools or 
 * associating with aspects, since @Service makes an ideal target for pointcuts.
 */

/**
 * Classe de serviços para a entidade Usuario.
 * @author "Marcelo Rezende Módolo"
 *
 */
@Service
@Transactional(readOnly = true)
public interface UsuarioService {

	/**
	 * Salva ou atualiza um usuário.
	 * @param usuario
	 * @return
	 */
	@Transactional
	public abstract Usuario save(Usuario usuario);		
		
	/**
	 * Retorna todos as usuários.
	 * @return
	 */
	public abstract List<Usuario> findAll();
	
	/**
	 * Retorna o usuário.
	 * @param id
	 * @return
	 */
	public abstract Usuario findOne(Long id);
	
	/**
	 * Retorna o Usuário pelo nome usado para autenticação no sistema.
	 * @param usuario
	 * @return
	 */
	public abstract Usuario findOne(String usuario);

	/**
	 * Retorna todos as usuários associados a um sítio.
	 * @return
	 */	
	public abstract List<Usuario> findAllBySitio(Sitio sitio); 
	
}
