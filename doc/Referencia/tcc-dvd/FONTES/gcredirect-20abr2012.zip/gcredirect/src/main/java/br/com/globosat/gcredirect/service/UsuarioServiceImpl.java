package br.com.globosat.gcredirect.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;
import br.com.globosat.gcredirect.repository.UsuarioRepository;

/*
 * We use @Transactional to make sure the save(…) operation is running in 
 * a transaction and to allow setting the readOnly-flag (at the class level) 
 * for findAll(...), findOne(...). 
 * This causes some performance optimizations inside the persistence provider 
 * as well as on the database level.
 */

/*
 * @Service serves as a specialization of @Component, allowing for 
 * implementation classes to be autodetected through classpath scanning. 
 * What this means is that you could annotate your service-layer 
 * classes with @Component, but by annotating them with @Service instead, 
 * your classes are more properly suited for processing by tools or 
 * associating with aspects, since @Service makes an ideal target for pointcuts.
 */

/**
 * 
 * @author "Marcelo Rezende Módolo"
 *
 */
@Service
@Transactional(readOnly = true)
public class UsuarioServiceImpl extends AbstractService<Usuario> implements UsuarioService {

	private static final Logger LOGGER = LoggerFactory.getLogger(UsuarioServiceImpl.class);
	
	@Autowired
	private UsuarioRepository repository; 
	
	
	@Override
	public List<Usuario> findAll() {
		return repository.findAll();
	}

	@Override
	public Usuario findOne(Long id) {
		return repository.findOne(id);
	}

	@Override
	public Usuario findOne(String usuario) {
		return repository.findOne(usuario);
	}

	@Override
	@Transactional
	public Usuario save(Usuario usuario) {
		auditaSalvar(LOGGER, usuario); //Auditoria
		return repository.save(usuario);
	}

	@Override
	public List<Usuario> findAllBySitio(Sitio sitio) {
		return repository.findAllBySitio(sitio);
	}

}
