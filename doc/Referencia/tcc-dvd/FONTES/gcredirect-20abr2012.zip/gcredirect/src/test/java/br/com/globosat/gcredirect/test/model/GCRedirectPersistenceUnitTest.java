package br.com.globosat.gcredirect.test.model;

import static org.junit.Assert.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.log4j.BasicConfigurator;
import org.junit.After;
import org.junit.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class GCRedirectPersistenceUnitTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(UsuarioTest.class);
	
	private EntityManagerFactory emFactory;	
	private EntityManager em;

	public GCRedirectPersistenceUnitTest() {
		BasicConfigurator.configure();
	}

	@Before
	public void setUp() throws Exception {
		try {
			LOGGER.info("Inicializando 'gcredirect_jdbc' para os testes");
			emFactory = Persistence.createEntityManagerFactory("gcredirect_jdbc");
			em = emFactory.createEntityManager();
		} catch (Exception e) {
			e.printStackTrace();
			fail("Falha ao instanciar EntityManager");
		}
	}

	@After
	public void tearDown() throws Exception {
		LOGGER.info("Parando Hibernate JPA layer.");
        if (em != null) {
            em.close();
        }
        if (emFactory != null) {
            emFactory.close();
        }
	}
	
	protected EntityManager getEntityManager() {
		return em;
	}
}
