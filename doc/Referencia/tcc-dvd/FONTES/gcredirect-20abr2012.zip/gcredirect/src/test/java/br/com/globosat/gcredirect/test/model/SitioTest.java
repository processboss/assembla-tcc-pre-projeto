package br.com.globosat.gcredirect.test.model;

import static junit.framework.Assert.assertNotNull;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.globosat.gcredirect.model.Redirecionamento;
import br.com.globosat.gcredirect.model.Sitio;

public class SitioTest extends GCRedirectPersistenceUnitTest {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(SitioTest.class);

	@Test
	public void possoCarregarUmSitio() {
		getEntityManager().getTransaction().begin();
		Sitio sitio = getEntityManager().find(Sitio.class, new Long(1));
		LOGGER.info(sitio.toString());
		getEntityManager().getTransaction().commit();
	}

	@Test
	public void possoCarregarTodosRedirecionamentos() {
		final EntityManager em = getEntityManager();
		em.getTransaction().begin();
		TypedQuery<Sitio> querySitio = getEntityManager().createQuery(
				"SELECT s From Sitio s WHERE s.sigla = :sigla", Sitio.class);
		Sitio sitio = querySitio.setParameter("sigla", "GNT").getSingleResult();
		assertNotNull(sitio);
		LOGGER.info(sitio.toString());

		TypedQuery<Redirecionamento> queryRedirecionamento = getEntityManager()
				.createQuery(
						"SELECT r From Redirecionamento r WHERE r.sitio.sigla = :sigla",
						Redirecionamento.class);
		queryRedirecionamento.setParameter("sigla", "GNT");
		List<Redirecionamento> redirecionamentos = queryRedirecionamento
				.getResultList();
		for (Redirecionamento r : redirecionamentos) {
			StringBuilder sb = new StringBuilder("Redirect ");
			sb.append(r.getStatus().toString())
			.append("  /").append(r.getUrlAntiga())
			.append(" http://").append(sitio.getUrlSitio())
			.append("/").append(r.getUrlNova());
					
			LOGGER.info(sb.toString());
		}
		em.getTransaction().commit();

	}
}
