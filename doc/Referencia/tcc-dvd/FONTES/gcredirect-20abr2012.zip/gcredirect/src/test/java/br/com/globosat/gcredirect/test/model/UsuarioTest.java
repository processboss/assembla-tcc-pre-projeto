package br.com.globosat.gcredirect.test.model;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import static junit.framework.Assert.*;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.globosat.gcredirect.model.Usuario;

public class UsuarioTest extends GCRedirectPersistenceUnitTest {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(UsuarioTest.class);

	@Test
	public void possoCarregarUmUsuarioPeloId() {
		getEntityManager().getTransaction().begin();
		Usuario usuario = getEntityManager().find(Usuario.class, new Long(1));
		assertNotNull(usuario);
		LOGGER.info(usuario.toString());
		getEntityManager().getTransaction().commit();
	}

	@Test
	public void possoCarregarUmUsuarioPeloUsuario() {
		final EntityManager em = getEntityManager();
		em.getTransaction().begin();
		TypedQuery<Usuario> query = getEntityManager().createQuery(
				"SELECT u From Usuario u WHERE u.usuario = :usuario", Usuario.class);
		Usuario usuario = query.setParameter("usuario", "modolo").getSingleResult();
		assertNotNull(usuario);
		LOGGER.info(usuario.toString());
		em.getTransaction().commit();
	}

}
