package br.com.globosat.gcredirect.test.service;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AbstractServiceTest {

	private static final String SEPARADOR = "**************************************************";
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(AbstractServiceTest.class);

	
	protected void info(String msg) {
		final StringBuilder sb = new StringBuilder("\n");
		sb.append(SEPARADOR)
		.append("\n\t")
		.append(msg).append("\n")
		.append(SEPARADOR).append("\n");
		LOGGER.info(sb.toString());
	}	
	
}
