package br.com.globosat.gcredirect.test.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;

import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.service.ArquivoRedirecionamentoService;
import br.com.globosat.gcredirect.service.SitioService;

/**
 * ArquivoRedirecionamentoServiceTest verifica se é possível criar<br>
 * o arquivo de redirecionamentos.
 * Objetivos<br>
 * <ul>
 * <li>Verificar que é possível retornar todas as linhas do arquivo.
 * <li>
 * </ul>
 * @author "Marcelo Rezende Módolo"
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners(value = {
		DependencyInjectionTestExecutionListener.class,
		DirtiesContextTestExecutionListener.class,
		TransactionalTestExecutionListener.class })
@ContextConfiguration("classpath:gcredirect-context-test.xml")
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
public class ArquivoRedirecionamentoServiceTest extends AbstractServiceTest {

	@Autowired
	private SitioService sitioService;
	
	@Autowired
	private ArquivoRedirecionamentoService arquivoRedirecionamentoService;

	@Test
	public void testFindAll() {
		Sitio s = TestUtil.encontraUmSitioQualquer(sitioService);
		List<String> linhas = arquivoRedirecionamentoService.findAll(s);
		assertNotNull(linhas);
		for (String l : linhas) {
			info(l);
		}
	}

	@Test
	public void testGerarArquivo() {
		Sitio s = TestUtil.encontraUmSitioQualquer(sitioService);
		boolean salvo = arquivoRedirecionamentoService.gerarArquivo(s);
		assertTrue(salvo);
	}
}
