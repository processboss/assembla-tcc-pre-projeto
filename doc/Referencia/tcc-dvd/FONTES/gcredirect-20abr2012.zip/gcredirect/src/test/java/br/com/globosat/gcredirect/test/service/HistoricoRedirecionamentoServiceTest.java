package br.com.globosat.gcredirect.test.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;

import br.com.globosat.gcredirect.model.HistoricoRedirecionamento;
import br.com.globosat.gcredirect.model.Redirecionamento;
import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;
import br.com.globosat.gcredirect.service.HistoricoRedirecionamentoService;
import br.com.globosat.gcredirect.service.RedirecionamentoService;
import br.com.globosat.gcredirect.service.SitioService;
import br.com.globosat.gcredirect.service.UsuarioService;

/**
 * HistoricoRedirecionamentoServiceTest verifica e valida as regras de<br>
 * negócio para a camada de serviços dos históricos.
 * <p>
 * Objetivos<br>
 * <ul>
 * <li>Verfificar que é possível recuperar o histórico pelo sítio.
 * <li>Verfificar que é possível recuperar o histórico pelo ID do sítio.
 * <li>Verfificar que é possível recuperar o histórico pela URL antiga.
 * <li>Verfificar que é possível recuperar o histórico pela URL nova.
 * <li>Verfificar que é possível recuperar o histórico pelo usuário.
 * <li>Verfificar que é possível recuperar o histórico pelo ID do usuário.
 * <li>Verfificar que é possível recuperar o histórico pelo ID do redirecionamento.
 * </ul>
 * 
 * @author "Marcelo Rezende Módolo"
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners(value = {
		DependencyInjectionTestExecutionListener.class,
		DirtiesContextTestExecutionListener.class,
		TransactionalTestExecutionListener.class })
@ContextConfiguration("classpath:gcredirect-context-test.xml")
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
public class HistoricoRedirecionamentoServiceTest extends AbstractServiceTest {

	@Autowired
	private UsuarioService usuarioService;

	@Autowired
	private SitioService sitioService;

	@Autowired
	private HistoricoRedirecionamentoService historicoRedirecionamentoService;
	
	@Autowired
	private RedirecionamentoService redirecionamentoService;

	@Test
	public void testFindAllByUsuarioUsuario() {
		final Usuario u = TestUtil.encontraUmUsuarioQualquer(usuarioService);
		final List<HistoricoRedirecionamento> rs = historicoRedirecionamentoService.findAllByUsuario(u);
		assertNotNull(rs);
		if(rs.isEmpty()) {
			info("Nenhum histórico para " + u.getNome());
		}
		info("HistoricoRedirecionamentoService::testFindAllByUsuarioUsuario() => OK");
	}

	@Test
	public void testFindAllByUsuarioLong() {
		final Usuario u = TestUtil.encontraUmUsuarioQualquer(usuarioService);
		final List<HistoricoRedirecionamento> rs = historicoRedirecionamentoService.findAllByUsuario(u.getId());
		assertNotNull(rs);
		if(rs.isEmpty()) {
			info("Nenhum histórico para " + u.getNome());
		}
		info("HistoricoRedirecionamentoService::testFindAllByUsuarioLong() => OK");		
	}

	@Test
	public void testFindAllBySitioSitio() {
		final Sitio s = TestUtil.encontraUmSitioQualquer(sitioService);
		final List<HistoricoRedirecionamento> rs = historicoRedirecionamentoService.findAllBySitio(s);
		assertNotNull(rs);
		if(rs.isEmpty()) {
			info("Nenhum histórico para " + s.getNome());
		}
		info("HistoricoRedirecionamentoService::testFindAllBySitioSitio() => OK");				
	}

	@Test
	public void testFindAllBySitioLong() {
		final Sitio s = TestUtil.encontraUmSitioQualquer(sitioService);
		final List<HistoricoRedirecionamento> rs = historicoRedirecionamentoService.findAllBySitio(s.getId());
		assertNotNull(rs);
		if(rs.isEmpty()) {
			info("Nenhum histórico para " + s.getNome());
		}
		info("HistoricoRedirecionamentoService::testFindAllBySitioSitio() => OK");						
	}

	@Test
	public void testFindAllBySitioUrlNova() {
		final Sitio s = TestUtil.encontraUmSitioQualquer(sitioService);
		final List<Redirecionamento> rs = redirecionamentoService.findAllBySitio(s);
		final Redirecionamento r = rs.get(TestUtil.getNextRandomInt(rs.size())); 
		final List<HistoricoRedirecionamento> hrs = 
				historicoRedirecionamentoService.findAllBySitioUrlNova(s, r.getUrlNova());
		assertNotNull(hrs);
		if(hrs.isEmpty()) {
			info("Nenhum histórico para " + s.getNome() + ", URL nova " + r.getUrlNova());
		}
		info("HistoricoRedirecionamentoService::testFindAllBySitioUrlNova() => OK");								
	}

	@Test
	public void testFindAllBySitioUrlAntiga() {
		final Sitio s = TestUtil.encontraUmSitioQualquer(sitioService);
		final List<Redirecionamento> rs = redirecionamentoService.findAllBySitio(s);
		final Redirecionamento r = rs.get(TestUtil.getNextRandomInt(rs.size())); 
		final List<HistoricoRedirecionamento> hrs = 
				historicoRedirecionamentoService.findAllBySitioUrlAntiga(s, r.getUrlAntiga());
		assertNotNull(hrs);
		if(hrs.isEmpty()) {
			info("Nenhum histórico para " + s.getNome() + ", URL antiga " + r.getUrlAntiga());
		}
		info("HistoricoRedirecionamentoService::testFindAllBySitioUrlAntiga() => OK");								
	}

	@Test
	public void testFindByRedirecionamentoId() {
		final Sitio s = TestUtil.encontraUmSitioQualquer(sitioService);
		final List<Redirecionamento> rs = redirecionamentoService.findAllBySitio(s);
		final Redirecionamento r = rs.get(TestUtil.getNextRandomInt(rs.size())); 
		
		final List<HistoricoRedirecionamento> hrs = 
				historicoRedirecionamentoService.findByRedirecionamentoId(r.getId());
		assertNotNull(hrs);
		assertFalse(hrs.isEmpty());
		info("HistoricoRedirecionamentoService::testFindByRedirecionamentoId() => OK");										
	}

}
