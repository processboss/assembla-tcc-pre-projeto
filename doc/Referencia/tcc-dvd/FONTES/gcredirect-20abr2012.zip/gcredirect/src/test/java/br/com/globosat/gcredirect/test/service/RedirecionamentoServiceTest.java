package br.com.globosat.gcredirect.test.service;

import static org.junit.Assert.*;

import java.util.Collections;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import br.com.globosat.gcredirect.model.HistoricoRedirecionamento;
import br.com.globosat.gcredirect.model.Redirecionamento;
import br.com.globosat.gcredirect.model.Regra;
import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.StatusRedirecionamento;
import br.com.globosat.gcredirect.model.Usuario;
import br.com.globosat.gcredirect.service.HistoricoRedirecionamentoService;
import br.com.globosat.gcredirect.service.RedirecionamentoService;
import br.com.globosat.gcredirect.service.RegraService;
import br.com.globosat.gcredirect.service.SitioService;
import br.com.globosat.gcredirect.service.UsuarioService;

/**
 * RedirecionamentoServiceTest verifica e valida as regras de<br>
 * negócio para a camada de serviços dos redirecionamentos.
 * <p>
 * Objetivos<br>
 * <ul>
 * <li>FindAllBySitio - Verificar que é possível obter todos os
 * redirecionamentos para um Sítio.
 * <li>CriarNovo - Verificar que é possível criar um redirecionamento e que essa
 * operação dever ser auditada.
 * <li>Excluir - Verificar que é possível excluir um redirecionamento e que essa
 * operação dever ser auditada.
 * <li>Verificar que não é possível criar um redirecionamento com sitio, url nova e url antiga já existentes.
 * </ul>
 * 
 * @author "Marcelo Rezende Módolo"
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners(value = {
		DependencyInjectionTestExecutionListener.class,
		DirtiesContextTestExecutionListener.class,
		TransactionalTestExecutionListener.class })
@ContextConfiguration("classpath:gcredirect-context-test.xml")
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
public class RedirecionamentoServiceTest extends AbstractServiceTest {

	private static String REGRA_EDITOR = "ROLE_EDITOR";

	@Autowired
	private RedirecionamentoService redirecionamentoService;

	@Autowired
	private SitioService sitioService;

	@Autowired
	private RegraService regraService;

	@Autowired
	private UsuarioService usuarioService;

	@Autowired
	private HistoricoRedirecionamentoService historicoRedirecionamentoService;

	@Autowired
	private PlatformTransactionManager transactionManager;

	@Test
	public void testFindAllBySitio() {
		final Sitio sitio = TestUtil.encontraUmSitioQualquer(sitioService);
		assertNotNull(sitio);
		List<Redirecionamento> redirecionamentos = redirecionamentoService
				.findAllBySitio(sitio);
		assertNotNull(redirecionamentos);
		if (redirecionamentos.isEmpty()) {
			info("RedirecionamentoServiceTest::testFindAllBySitio() => Nenhum redirecionamento para o sítio: "
					+ sitio.getNome());
		} else {
			info("RedirecionamentoServiceTest::testFindAllBySitio() => "
					+ redirecionamentos.size()
					+ "# redirecionamentos encontrados para o sítio: "
					+ sitio.getNome());
		}
	}

	@Test
	@Transactional
	public void testCriarNovo() {
		final Regra r = regraService.findOne(REGRA_EDITOR);
		final List<Usuario> usuarios = usuarioService.findAll();

		// O usuário deve ser um EDITOR e estar ATIVO
		Usuario usuario = null;
		for (Usuario u : usuarios) {
			if (u.getRegras().contains(r) && u.isAtivo()) {
				usuario = u;
				break;
			}
		}
		final Sitio sitio = (usuario.getSitios().toArray(new Sitio[0]))[0];
		Redirecionamento redirecionamento = new Redirecionamento(null, sitio,
				StatusRedirecionamento.PERMANENT, "_TEST_URL_ANTIGA",
				"_TEST_URL_NOVA");
		doCriarNovo(redirecionamento, usuario);
	}

	private void doCriarNovo(Redirecionamento redirecionamento, Usuario usuario) {
		redirecionamento = redirecionamentoService.criarNovo(redirecionamento,
				usuario);
		assertNotNull(redirecionamento.getId());
		List<HistoricoRedirecionamento> hrs = historicoRedirecionamentoService
				.findByRedirecionamentoId(redirecionamento.getId());
		assertFalse(hrs.isEmpty());
		info("RedirecionamentoServiceTest::testCriarNovo() => "
				+ redirecionamento);
		for (HistoricoRedirecionamento hr : hrs) {
			info("RedirecionamentoServiceTest::testCriarNovo() => " + hr);
		}
	}

	@Test
	@Transactional
	public void testExcluir() {
		final List<Sitio> sitios = sitioService.findAll();
		List<Redirecionamento> redirecionamentos = Collections.emptyList();

		Sitio sitio = null;
		for (Sitio s : sitios) {
			redirecionamentos = redirecionamentoService.findAllBySitio(s);
			if (!redirecionamentos.isEmpty())
				sitio = s;
			break;
		}

		final Regra r = regraService.findOne(REGRA_EDITOR);
		final List<Usuario> usuarios = usuarioService.findAll();
		// O usuário deve ser um EDITOR e estar ATIVO
		// Para remover um Redirecionamento, o editor deve estar ativo e
		// ser associado ao sitio:
		Usuario autor = null;
		for (Usuario u : usuarios) {
			if (u.isAtivo() && u.getRegras().contains(r)
					&& u.getSitios().contains(sitio)) {
				autor = u;
				break;
			}
		}

		Redirecionamento redirecionamento = redirecionamentos.get(TestUtil
				.getNextRandomInt(redirecionamentos.size()));

		redirecionamentoService.excluir(redirecionamento, autor);
		List<HistoricoRedirecionamento> hrs = historicoRedirecionamentoService
				.findByRedirecionamentoId(redirecionamento.getId());
		assertFalse(hrs.isEmpty());
		info("RedirecionamentoServiceTest::testExcluir() => "
				+ redirecionamento);
		for (HistoricoRedirecionamento hr : hrs) {
			info("RedirecionamentoServiceTest::testExcluir() => " + hr);
		}

	}

	/*
	 * Se for declarado como @Transactional não será possível capturar
	 * DataIntegrityViolationException. Como solução podemos criar uma transação
	 * de forma não declarativa e tentar com isso disprar a exception.
	 */
	@Test(expected = DataIntegrityViolationException.class)
	public void deveFalharSalvarSitioUrlNovaUrlAntigaDuplicado() {
		final TransactionTemplate transactionTemplate = new TransactionTemplate(
				transactionManager);
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {

			@Override
			protected void doInTransactionWithoutResult(TransactionStatus arg0) {
				final Regra r = regraService.findOne(REGRA_EDITOR);
				final List<Usuario> usuarios = usuarioService.findAll();

				// O usuário deve ser um EDITOR e estar ATIVO
				Usuario usuario = null;
				for (Usuario u : usuarios) {
					if (u.getRegras().contains(r) && u.isAtivo()) {
						usuario = u;
						break;
					}
				}
				final Sitio sitio = (usuario.getSitios().toArray(new Sitio[0]))[0];
				final List<Redirecionamento> redirecionamentos = redirecionamentoService
						.findAllBySitio(sitio);
				final Redirecionamento redirecionamento = redirecionamentos.get(TestUtil
						.getNextRandomInt(redirecionamentos.size()));
				Redirecionamento clone = new Redirecionamento(null, sitio,
						StatusRedirecionamento.PERMANENT, redirecionamento.getUrlAntiga(),
						redirecionamento.getUrlNova());
				doCriarNovo(clone, usuario);
			}
		});
	}

}
