package br.com.globosat.gcredirect.test.service;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;

import br.com.globosat.gcredirect.model.Regra;
import br.com.globosat.gcredirect.model.Usuario;
import br.com.globosat.gcredirect.service.RegraService;
import br.com.globosat.gcredirect.service.UsuarioService;

/**
 * RegraServiceTest verifica e valida as regras de<br>
 * negócio para a camada de serviços das regras.
 * <p>
 * Objetivos<br>
 * <ul>
 * <li>Verificar que não é possível criar uma regra com nome duplicado.
 * <li>Verificar que é possível retornar todas as regras.
 * <li>Verificar que é possível retornar todas as regras pelo usuário.
 * <li>Verificar que é possível retornar todas as regras pelo id do usuário.
 * <li>Verificar que é possível retornar uma regra pelo id.
 * <li>Verificar que é possível retornar uma regra pelo nome.
 * <li>Verificar que é possível salvar uma nova regra.
 * </ul>
 * 
 * @author "Marcelo Rezende Módolo"
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners(value = {
		DependencyInjectionTestExecutionListener.class,
		DirtiesContextTestExecutionListener.class, TransactionalTestExecutionListener.class })
@ContextConfiguration("classpath:gcredirect-context-test.xml")
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
public class RegraServiceTest extends AbstractServiceTest {


	@Autowired
	private RegraService regraService;
	
	@Autowired
	private UsuarioService usuarioService;
		
	@Test
	public void salvarRegra() {
		Regra regra = new Regra(null, "_TEST_REGRA");
		regra = regraService.save(regra);
		assertFalse(regra.getId() == null);
		info(regra.toString());
	}

	@Test(expected = DataIntegrityViolationException.class)
	public void deveFalharSalvarNomeDuplicado() {
		final Regra r = TestUtil.encontraUmaRegraQualquer(regraService);
		assertNotNull(r);
		assertFalse(r.getId() == null);
		Regra clone = new Regra(null, r.getNome());
		info("Tentando criar uma nova Regra com um nome existente - nome: "
				+ clone.getNome());
		clone = regraService.save(clone);
	}

	@Test
	public void encontarTodos() {
		final List<Regra> regras = regraService.findAll();
		assertNotNull(regras);
		assertFalse(regras.isEmpty());
		info(regras.size() + "# regras encontradas");
	}

	@Test
	public void encontrarUm() {
		final Regra r = TestUtil.encontraUmaRegraQualquer(regraService);
		assertNotNull(r);
		assertFalse(r.getId() == null);
		assertThat(r, is(regraService.findOne(r.getId()) ));
		info(r.toString());
	}

	@Test 
	public void encontrarUmPeloNome() {
		final Regra r = TestUtil.encontraUmaRegraQualquer(regraService);
		assertNotNull(r);
		assertFalse(r.getId() == null);
		assertThat(r, is(regraService.findOne(r.getNome()) ));
		info(r.toString());		
	}
	
	@Test
	public void encontrarPeloUsuario() {
		final Usuario u = TestUtil.encontraUmUsuarioQualquer(usuarioService);
		final List<Regra> regras = regraService.findByUsuario(u);
		assertNotNull(regras);
		assertFalse(regras.isEmpty());
		assertTrue(regras.size() == u.getRegras().size());
		assertTrue(regras.containsAll(u.getRegras()));
		info(u.getNome());
		info(regras.toString());
	}

	@Test
	public void encontrarPeloUsuarioId() {
		final Usuario u = TestUtil.encontraUmUsuarioQualquer(usuarioService);
		final List<Regra> regras = regraService.findByUsuario(u.getId());
		assertNotNull(regras);
		assertFalse(regras.isEmpty());
		assertTrue(regras.size() == u.getRegras().size());
		assertTrue(regras.containsAll(u.getRegras()));
		info(u.getNome());
		info(regras.toString());		
	}

}
