package br.com.globosat.gcredirect.test.service;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;

import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;
import br.com.globosat.gcredirect.service.SitioService;
import br.com.globosat.gcredirect.service.UsuarioService;

/**
 * SitioServiceTest verifica e valida as regras de<br>
 * negócio para a camada de serviços dos sítios.
 * <p>
 * Objetivos<br>
 * <ul>
 * <li>Verificar que não é possível criar um sítio com as propriedades nome, sigla ou url já existentes.
 * <li>Verfificar que é possível encontrar todos os sítios.
 * <li>Verfificar que é possível encontrar todos os sítios pelo usuário.
 * <li>Verfificar que é possível encontrar todos os sítios pelo ID do usuário.
 * <li>Verfificar que é possível encontrar um sítio.
 * <li>Verfificar que é possível salvar um sítio.
 * </ul>
 * 
 * @author "Marcelo Rezende Módolo"
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners(value = {
		DependencyInjectionTestExecutionListener.class,
		DirtiesContextTestExecutionListener.class,
		TransactionalTestExecutionListener.class })
@ContextConfiguration("classpath:gcredirect-context-test.xml")
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
public class SitioServiceTest extends AbstractServiceTest {

	@Autowired
	private SitioService sitioService;

	@Autowired
	private UsuarioService usuarioService;

	@Test
	public void encontrarTodos() {
		final List<Sitio> sitios = sitioService.findAll();
		assertNotNull(sitios);
		assertFalse(sitios.isEmpty());
		info("SitioServiceTest::encontrarTodos() -> Total de sítios retornado: "
				+ sitios.size());
	}

	@Test
	public void encontrarTodosPeloUsuario() {
		final Usuario u = TestUtil.encontraUmUsuarioQualquer(usuarioService);
		final List<Sitio> sitios = sitioService.findAllByUsuario(u);
		assertNotNull(sitios);
		assertFalse(sitios.isEmpty());
		assertTrue(sitios.size() == u.getSitios().size());
		assertTrue(sitios.containsAll(u.getSitios()));
		info("SitioServiceTest::encontrarTodosPeloUsuario(): "
				+ sitios.toString());
	}

	@Test
	public void encontrarTodosPeloUsuarioId() {
		final Usuario u = TestUtil.encontraUmUsuarioQualquer(usuarioService);
		final List<Sitio> sitios = sitioService.findAllByUsuario(u.getId());
		assertNotNull(sitios);
		assertFalse(sitios.isEmpty());
		assertTrue(sitios.size() == u.getSitios().size());
		assertTrue(sitios.containsAll(u.getSitios()));
		info("SitioServiceTest::encontrarTodosPeloUsuarioId(): "
				+ sitios.toString());
	}

	@Test
	public void encontrarUm() {
		Sitio s = TestUtil.encontraUmSitioQualquer(sitioService);
		assertNotNull(s);
		assertThat(s, is(sitioService.findOne(s.getId())));
		info("SitioServiceTest::encontrarUm(): " + s.toString());
	}

	@Test
	public void findOneBySitioSigla() {
		final Sitio s1 = TestUtil.encontraUmSitioQualquer(sitioService);
		final Sitio s2 = sitioService.findOneBySitioSigla(s1.getSigla());
		assertNotNull(s2);
		assertThat(s1, is(sitioService.findOne(s2.getId())));
		info("SitioServiceTest::findOneBySitioSigla(): " + s2.toString());
	}
	
	@Test
	public void salvarSitio() {
		Sitio s = new Sitio(null, "_TEST_", "_TEST_", "_TEST_", "_TEST_",
				"_TEST_");
		s = sitioService.save(s);
		assertNotNull(s);
		assertNotNull(s.getId());
		info("SitioServiceTest::salvarSitio(): " + s.toString());

	}

	@Test(expected = DataIntegrityViolationException.class)
	public void deveFalharSalvarNomeDuplicado() {
		final Sitio s = TestUtil.encontraUmSitioQualquer(sitioService);
		assertNotNull(s);
		Sitio clone = new Sitio(null, s.getNome(), "_TEST_" + s.getSigla(),
				"_TEST_" + s.getUrlSitio(),
				s.getCaminhoArquivoRedirecionamento(),
				s.getArquivoRedirecionamento());
		info("Tentando criar um novo Sitio com um nome existente - nome: "
				+ s.getNome());
		clone = sitioService.save(clone);
	}

	@Test(expected = DataIntegrityViolationException.class)
	public void deveFalharSalvarSiglaDuplicada() {
		final Sitio s = TestUtil.encontraUmSitioQualquer(sitioService);
		assertNotNull(s);
		Sitio clone = new Sitio(null, "_TEST_" + s.getNome(), s.getSigla(),
				"_TEST_" + s.getUrlSitio(),
				s.getCaminhoArquivoRedirecionamento(),
				s.getArquivoRedirecionamento());
		info("Tentando criar um novo Sitio com uma sigla existente - sigla: "
				+ s.getSigla());
		clone = sitioService.save(clone);
	}

	@Test(expected = DataIntegrityViolationException.class)
	public void deveFalharSalvarUrlDuplicado() {
		final Sitio s = TestUtil.encontraUmSitioQualquer(sitioService);
		assertNotNull(s);
		Sitio clone = new Sitio(null, "_TEST_" + s.getNome(), "_TEST_"
				+ s.getSigla(), s.getUrlSitio(),
				s.getCaminhoArquivoRedirecionamento(),
				s.getArquivoRedirecionamento());
		info("Tentando criar um novo Sitio com um URL existente - URL: "
				+ s.getUrlSitio());
		clone = sitioService.save(clone);
	}

}
