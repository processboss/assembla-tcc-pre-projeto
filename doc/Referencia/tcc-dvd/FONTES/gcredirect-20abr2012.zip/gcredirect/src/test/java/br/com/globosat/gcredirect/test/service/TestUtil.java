package br.com.globosat.gcredirect.test.service;

import java.util.Date;
import java.util.List;
import java.util.Random;

import br.com.globosat.gcredirect.model.Regra;
import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;
import br.com.globosat.gcredirect.service.RegraService;
import br.com.globosat.gcredirect.service.SitioService;
import br.com.globosat.gcredirect.service.UsuarioService;

public class TestUtil {

	
	private TestUtil() {}
	
	static public Usuario encontraUmUsuarioQualquer(UsuarioService service) {
		final List<Usuario> usuarios = service.findAll();
		final Usuario u = usuarios.get(getNextRandomInt(usuarios.size()));		
		return u;
	}	

	static public Sitio encontraUmSitioQualquer(SitioService service) {
		final List<Sitio> sitios = service.findAll();
		final int index = getNextRandomInt(sitios.size());
		return sitios.get(index);
	}

	static public Regra encontraUmaRegraQualquer(RegraService service) {
		final List<Regra> regras = service.findAll();
		final int index = getNextRandomInt(regras.size());
		return regras.get(index);
	}
	
	static public int getNextRandomInt(int n) {
		final Long SEED = (new Date()).getTime();
		final Random RANDOM = new Random(SEED);		
		return RANDOM.nextInt(n);
	}	
}
