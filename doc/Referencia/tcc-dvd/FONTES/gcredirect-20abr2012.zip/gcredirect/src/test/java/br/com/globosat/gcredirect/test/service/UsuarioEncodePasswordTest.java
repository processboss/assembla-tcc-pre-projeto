package br.com.globosat.gcredirect.test.service;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.transaction.annotation.Transactional;

import br.com.globosat.gcredirect.model.Usuario;
import br.com.globosat.gcredirect.security.GCRedirectMD5PasswordEncoder;
import br.com.globosat.gcredirect.service.UsuarioService;

/**
 * UsuarioEncodePasswordTest verifica e atualiza o valor<br>
 * da senha para todo os usuários. A senha criada será composta do valor obtido
 * da propriedade usuario.
 * <p>
 * Objetivos<br>
 * <ul>
 * <li>Atualizar a propriedade senha com seu valor MD5.
 * <li>Verificar que é possível testar a senha gerada.
 * </ul>
 * 
 * @author "Marcelo Rezende Módolo"
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners(value = {
		DependencyInjectionTestExecutionListener.class,
		DirtiesContextTestExecutionListener.class,
		TransactionalTestExecutionListener.class })
@ContextConfiguration("classpath:gcredirect-context-test.xml")
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
public class UsuarioEncodePasswordTest extends AbstractServiceTest {

	@Autowired
	private UsuarioService usuarioService;

	@Test
	@Transactional
	public void testEncodePassword() {
		final List<Usuario> usuarios = usuarioService.findAll();
		assertNotNull(usuarios);
		assertFalse(usuarios.isEmpty());
		info(usuarios.size() + "# usuários encontrados");

		for (Usuario u : usuarios) {

			u.setSenha(GCRedirectMD5PasswordEncoder.encodePassword(u
					.getUsuario()));
			u = usuarioService.save(u);
			assertFalse(u.getSenha().equals(u.getUsuario()));
			final String senhaMD5 = GCRedirectMD5PasswordEncoder
					.encodePassword(u.getUsuario());
			assertTrue(u.getSenha().equals(senhaMD5));
		}
	}

}
