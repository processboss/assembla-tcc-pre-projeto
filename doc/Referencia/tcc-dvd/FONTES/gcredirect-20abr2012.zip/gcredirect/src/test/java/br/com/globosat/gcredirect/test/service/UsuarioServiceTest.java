package br.com.globosat.gcredirect.test.service;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import br.com.globosat.gcredirect.model.Regra;
import br.com.globosat.gcredirect.model.Sitio;
import br.com.globosat.gcredirect.model.Usuario;
import br.com.globosat.gcredirect.service.RegraService;
import br.com.globosat.gcredirect.service.SitioService;
import br.com.globosat.gcredirect.service.UsuarioService;

/**
 * UsuarioServiceTest verifica e valida as regras de<br>
 * negócio para a camada de serviços dos usuários.
 * <p>
 * Objetivos<br>
 * <ul>
 * <li>Verificar que não é possível criar um usuário com nome já existente.
 * <li>Verfificar que é possível encontrar todos os usuários.
 * <li>Verfificar que é possível bloquear e desbloquear um usuário.
 * <li>Verfificar que é possível encontrar um usuário pelo seu ID.
 * <li>Verfificar que é possível encontrar um usuário.
 * <li>Verfificar que é possível criar um novo usuário.
 * </ul>
 * 
 * @author "Marcelo Rezende Módolo"
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@TestExecutionListeners(value = {
		DependencyInjectionTestExecutionListener.class,
		DirtiesContextTestExecutionListener.class,
		TransactionalTestExecutionListener.class })
@ContextConfiguration("classpath:gcredirect-context-test.xml")
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
public class UsuarioServiceTest extends AbstractServiceTest {

	@Autowired
	private UsuarioService usuarioService;
	
	@Autowired
	private RegraService regraService;
	
	@Autowired
	private SitioService sitioService;

	@Autowired
	private PlatformTransactionManager transactionManager;
	
	@Test
	public void encontrarTodos() {
		final List<Usuario> usuarios = usuarioService.findAll();
		assertNotNull(usuarios);
		assertFalse(usuarios.isEmpty());
		info(usuarios.size() + "# usuários encontrados");
	}

	@Test
	public void encontrarPeloId() {
		final Usuario u1 = TestUtil.encontraUmUsuarioQualquer(usuarioService);
		final Usuario u2 = usuarioService.findOne(u1.getId());
		assertNotNull(u2);
		assertThat(u1, is(u2));
		info(u2.toString());
	}

	@Test
	public void encontrarPeloUsuario() {
		final Usuario u1 = TestUtil.encontraUmUsuarioQualquer(usuarioService);
		final Usuario u2 = usuarioService.findOne(u1.getUsuario());
		assertNotNull(u2);
		assertThat(u1, is(u2));
		info(u2.toString());
	}

	@Test
	@Transactional
	public void bloquearDesbloquearUsuario() {
		final boolean ATIVO = true;

		Usuario u1 = TestUtil.encontraUmUsuarioQualquer(usuarioService);
		u1.setAtivo(!ATIVO);
		u1 = usuarioService.save(u1);
		assertThat(!ATIVO, is(u1.isAtivo()));

		info("[BLOQUEANDO] Usuario " + u1.getNome() + ", ativo = "
				+ u1.isAtivo());

		u1.setAtivo(ATIVO);
		u1 = usuarioService.save(u1);
		assertThat(ATIVO, is(u1.isAtivo()));
		info("[DESBLOQUEANDO] Usuario " + u1.getNome() + ", ativo = "
				+ u1.isAtivo());

	}

	/*
	 * Diferente de RegraServiceTest, aqui é necessário declarar o método como
	 * transacional. O motivo disso são as coleções Regras e Sitios que devem
	 * estar contidas na mesma transação. 
	 */
	@Test
	@Transactional
	public void criarUsuario() {
		final Usuario u = TestUtil.encontraUmUsuarioQualquer(usuarioService);

		Usuario outro = new Usuario(null, "_TESTE_" + u.getNome(), "_TESTE_"
				+ u.getEmail(), "_TESTE_" + u.getSenha(), "_TESTE_"
				+ u.getUsuario(), !u.isAtivo(), "_TESTE_" + u.getTelefone(),
				u.getRegras(), u.getSitios());
		outro = usuarioService.save(outro);
		assertFalse(outro.getId() == null);
		info(outro.toString());
	}

	/*
	 * Se for declarado como @Transactional não será possível capturar
	 * DataIntegrityViolationException. Como solução podemos criar uma
	 * transação de forma não declarativa e tentar com isso disprar a exception.
	 */
	@Test(expected = DataIntegrityViolationException.class)
	public void deveFalharSalvarNomeDuplicado() {
		final TransactionTemplate transactionTemplate = new TransactionTemplate(transactionManager);
		
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				final Usuario u = TestUtil.encontraUmUsuarioQualquer(usuarioService);
				assertNotNull(u);
				assertFalse(u.getId() == null);
				final Set<Regra> regras = new HashSet<Regra>(regraService.findAll());
				final Set<Sitio> sitios = new HashSet<Sitio>(sitioService.findAll());
				
				Usuario clone = new Usuario(null, u.getNome(),  u.getEmail(), u.getSenha(), 
						u.getUsuario(), u.isAtivo(),  u.getTelefone(),
						regras, sitios);
				info("Tentando criar um novo Usuario com um nome de usuário existente - nome: "
						+ clone.getUsuario());
				clone = usuarioService.save(clone);						
			}
		});
		
	}
	
}
